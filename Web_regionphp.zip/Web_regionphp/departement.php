<!DOCTYPE html> 
<html lang="fr">

<head> 

<link	rel="stylesheet"	href="yourjob.css"	type="text/css"	media="screen"/>
<meta charset ="UTF-8">
<title>YourJob - R&eacute;gion</title>

</head>

<body>
/*Barre menu*/
<div id="menu">
	<DIV><img id="logo"src="images/logo.jpg" alt="" />
	</DIV>

	<ul>
		<li id="pasm"><a href="page_accueil.html">ACCUEIL</a></li>
		<li id="pasm"><a href="page_accueil.html">RECHERCHE PAR ACTIVIT&Eacute;</a></li>
		<li id="pasm"><a href="recherche_region.php">RECHERCHE PAR R&Eacute;GION</a></li>
		<li id="pasm"><a href="page_accueil.html">CONSEILS CANDIDATURE</a></li>
	</ul>
	
	
</div>
<div id="menu2">
	<ul id="connex">
		<li id="Gc"><a href="page_accueil.html">Nouveau utilisateur</a></li>
		<li id="Dc"><a href="page_accueil.html">Connexion</a></li>
	</ul>
</div>	
	
<nav id="navi">
	<ul>
		<li id="passif1"><a href="recherche_region.php">REGION</a>
		</li>
		<li id="act1"><a href="recherche_region.php">D&Eacute;PARTEMENT</a>
		</li>
	</ul>
</nav>








<div class="bord" id="gauche">

	<p>Voici votre r&eacute;gion :</p>
	</br>
	<?php
			echo "<img src='images/".$_GET['id_r'].".png' alt='dep'>";
	?>
</div>

<p id="ou">
	<strong>OU</strong>
</p>

<div class="bord">
	<p>Choisissez votre département ou votre commune de recherche : </p>
	<form method="post" action="departement_seul.php" id="rech">
		<p>
			<label for="dep">Choix d'un d&eacute;partement</label><br />
			<select name="dep" id="dep">
			<?php
				$bdd = new PDO('mysql:host=localhost;dbname=yourjob1', 'root', '');
				$req="SELECT distinct id_Dep, departement.departement FROM departement, entreprise where entreprise.Departement = departement.id_Dep AND entreprise.Region=".$_GET['id_r'];
				$reponse = $bdd->query($req);
					 
				while ($donnees = $reponse->fetch())
				{
			?>
			<option name="dep"> <?php echo $donnees['id_Dep']." - ".$donnees['departement']; ?></option>
			<?php
				}
			?>
			</select>
		</p>
		<p>
			<INPUT TYPE="submit" NAME="envoie" VALUE="Rechercher">
	   </p>
	</form>
	<form method="post" action="commune.php" id="rech">
		<p>
			Choisissez votre commune de recherche :
		</p>
	
	   <p>
			<input type="text" name="comm" id="commune" placeholder="Saisir une commune">
	   </p>
	   <p>
			<INPUT TYPE="submit" NAME="envoie" VALUE="Rechercher">
	   </p>
	</form>
	
</div>

<div class="bord">
	<p>
		Les domaines d'activit&eacute;s majoritaires du pays :
	</p>
	<ul>
		<li>Liste des domaines principaux
		</li>
	</ul>
	<table>
		<tr>
			<th>Nom d&eacute;partement</th><th>Industrie</th><th>Construction</th><th>Transport, Restauration et hotellerie</th><th>ESME</th><th>ESMM</th><th>Commerce</th>
		</tr>
		<?php
		
		$requete = $bdd->query('SELECT distinct departement.departement, sum(industrie)/(sum(totale)+sum(commerce))*100 as ind, sum(construction)/(sum(totale)+sum(commerce))*100 as cons, sum(TRH)/(sum(totale)+sum(commerce))*100 as trans, sum(ESME)/(sum(totale)+sum(commerce))*100 as ESM, sum(ESMM)/(sum(totale)+sum(commerce))*100 as ES, sum(commerce)/(sum(totale)+sum(commerce))*100 as com FROM departement, entreprise where entreprise.Departement = departement.id_Dep AND entreprise.Region="'.$_GET['id_r'].'" group by departement.departement');
			 
			while ($data = $requete->fetch())
			{
			echo"
			<tr>
				<td>".$data['departement']."</td><td>".$data['ind']." % </td><td>".$data['cons']." % </td><td>".$data['trans']." % </td><td>".$data['ESM']." % </td><td>".$data['ES']." % </td><td>".$data['com']." % </td>
			</tr>";
			}
		$requete ->closeCursor(); 
	?>
	</table>
</div>









<footer id="support">
   <table>
   <tr>
   <td>
   <u>  FAQ </u>  
   </td> 
      </tr>
	     <tr>
   <td> Liens utiles </td>
   </tr>
   <tr>
   <td> <u>   Support </u>  </td>
   </tr>
   </table>
   </footer>


</body>
</html>