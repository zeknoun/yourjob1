<!DOCTYPE html> 
<html lang="fr">

<head> 

<link	rel="stylesheet"	href="yourjob.css"	type="text/css"	media="screen"/>
<meta charset ="UTF-8">
<title>YourJob - R&eacute;gion</title>

</head>

<body>
/*Barre menu*/
<div id="menu">
	<DIV><img id="logo"src="images/logo.jpg" alt="" />
	</DIV>

	<ul>
		<li id="pasm"><a href="page_accueil.html">ACCUEIL</a></li>
		<li id="pasm"><a href="page_accueil.html">RECHERCHE PAR ACTIVIT&Eacute;</a></li>
		<li id="pasm"><a href="recherche_region.html">RECHERCHE PAR R&Eacute;GION</a></li>
		<li id="pasm"><a href="page_accueil.html">CONSEILS CANDIDATURE</a></li>
	</ul>
	
	
</div>
<div id="menu2">
	<ul id="connex">
		<li id="Gc"><a href="page_accueil.html">Nouveau utilisateur</a></li>
		<li id="Dc"><a href="page_accueil.html">Connexion</a></li>
	</ul>
</div>	
	
<nav id="navi">
	<ul>
		<li id="act"><a href="page_accueil.html">REGION</a>
		</li>
		<li id="passif1"><a href="page_accueil.html">D&Eacute;PARTEMENT</a>
		</li>
		<li id="passif2"><a href="page_accueil.html">COMMUNE</a>
		</li>
	</ul>
</nav>










<footer id="support">
   <table>
   <tr>
   <td>
   <u>  FAQ </u>  
   </td> 
      </tr>
	     <tr>
   <td> Liens utiles </td>
   </tr>
   <tr>
   <td> <u>   Support </u>  </td>
   </tr>
   </table>
   </footer>


</body>
</html>