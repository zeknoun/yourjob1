<html>
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<title>Document sans titre</title>
</head>
 
<body>
<?php
try
{
    $bdd = new PDO('mysql:host=localhost;dbname=projet', 'root', '');
}
catch(Exception $e)
{
    die('Erreur : '.$e->getMessage());
}
?>
<form method="post" action="enregistrement_e.php">
 
    <label for="region">Region:</label><br />
     <select name="region" id="region">
 
<?php
$bdd = new PDO('mysql:host=localhost;dbname=projet', 'root', '');
$reponse = $bdd->query('SELECT Nom_REG FROM region');
 
while ($donnees = $reponse->fetch())
{
?>
           <option value="<?php echo $donnees['Nom_REG']; ?>"> <?php echo $donnees['Nom_REG']; ?></option>
<?php
}
 
?>
</select>
 
</form>
</body>
</html>