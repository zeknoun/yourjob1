<!DOCTYPE html> 
<html lang="fr">

<head> 

<link	rel="stylesheet"	href="yourjob.css"	type="text/css"	media="screen"/>
<meta charset ="UTF-8">
<title>YourJob - R&eacute;gion</title>

</head>

<body>
/*Barre menu*/
<div id="menu">
	<DIV><img id="logo"src="images/logo.jpg" alt="" />
	</DIV>

	<ul>
		<li id="pasm"><a href="page_accueil.html">ACCUEIL</a></li>
		<li id="pasm"><a href="page_accueil.html">RECHERCHE PAR ACTIVIT&Eacute;</a></li>
		<li id="pasm"><a href="recherche_region.php">RECHERCHE PAR R&Eacute;GION</a></li>
		<li id="pasm"><a href="page_accueil.html">CONSEILS CANDIDATURE</a></li>
	</ul>
	
	
</div>
<div id="menu2">
	<ul id="connex">
		<li id="Gc"><a href="page_accueil.html">Nouveau utilisateur</a></li>
		<li id="Dc"><a href="page_accueil.html">Connexion</a></li>
	</ul>
</div>	
	
<nav id="navi">
	<ul>
		<li id="act"><a href="page_accueil.html">REGION</a>
		</li>
		<li id="passif1"><a href="page_accueil.html">D&Eacute;PARTEMENT</a>
		</li>
		<li id="passif2"><a href="page_accueil.html">COMMUNE</a>
		</li>
	</ul>
</nav>

<div class="bord" id="gauche">
	<p>S&eacute;lectionnez votre zone de recherche :</p>
	</br>
	<script src="cmap/france-map.js"></script>
	<script>francefree();</script>
</div>

<p id="ou">
	<strong>OU</strong>
</p>

<div class="bord">
	<p>
		Choisissez votre d&eacute;partement ou votre commune de recherche :
	</p>
	
	<form method="post" action="traitement.php" id="rech">
		<p>
		   <label for="dep">Choix d'un d&eacute;partement</label><br />
		   <select name="dep" id="dep">
		   <?php
				$bdd = new PDO('mysql:host=localhost;dbname=projet', 'root', '');
				$reponse = $bdd->query('SELECT id_Dep, departement FROM departement');
				 
				while ($donnees = $reponse->fetch())
				{
			?>
				<option value="<?php echo $donnees['id_Dep']; ?>"> <?php echo $donnees['id_Dep']." - ".$donnees['Nom_REG']; ?></option>
			<?php
				}
			?>
		   </select>
	   </p>
	   <p>
			<input type="text" name="commune" id="commune" placeholder="Saisir une commune">
	   </p>
	   <p>
			<INPUT TYPE="submit" NAME="envoie" VALUE="Rechercher">
	   </p>
	</form>
	
</div>

<div class="bord">
	<p>
		Les domaines d'activit&eacute;s majoritaires du pays :
	</p>
	<ul>
		<li>Liste des domaines principaux
		</li>
	</ul>
</div>

<p id="graph">
	Observation des tendances entreupreunariales :
</p>





<footer id="support">
   <table>
   <tr>
   <td>
   <u>  FAQ </u>  
   </td> 
      </tr>
	     <tr>
   <td> Liens utiles </td>
   </tr>
   <tr>
   <td> <u>   Support </u>  </td>
   </tr>
   </table>
   </footer>


</body>
</html>