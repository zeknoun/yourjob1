<?php
 session_start();
 ?>
<html>
<head>
    	<link rel="stylesheet"	href="yourjob.css"	type="text/css"	media="screen"	/>	
	<meta charset="utf-8"/>	
    <title> Résultat	</title>	
    
<style>
    #cercle{
    width: 200px; 
    padding-top: 10px; 
    padding-bottom: 10px; 
    border: 3px solid black; 
    text-align: center; 
    background: grey;
    border-radius: 10px;
    color: white;
        
    }
    h1{color: blue;}
</style>
    
    </head>
    <body>
 <?php 
include("menu.php");
?>	
        <nav id="navi">
    <ul>
        <li id="passif1"><a href="recherche_activite.php">Activité</a>
        </li>
        <li id="act1"><a href="resultat_activite.php">Résultat de la recherche</a>
        </li>
        </ul>
        </nav>
<table>
    <tr><td><h1><?php
        if(isset($_POST['submit'])){
$selected_val = $_POST['test'];  
echo "Vous avez selectionné:"." ". $selected_val ;
        
?></h1></td>
        
<td><form method="post" action="recherche_activite.php">
    <input type="submit" name="submit" value="Changer de secteur d'activite" />
</form></td></tr>
<br/>
    
    <tr>
        <th><h2>Départements</h2></th>
        <th><h2>% de chances</h2></th>
    </tr>
<br/>
<?php
$bdd = new PDO('mysql:host=localhost;dbname=yourjob1;charset=utf8','root', '');

if($selected_val=="industrie"){
    $query1 = "SELECT departement.departement as nom_dep1, SUM(entreprise.industrie) * 100 / (SELECT SUM(industrie) FROM entreprise) as pourcentage1 from entreprise inner join departement on entreprise.Departement=departement.id_Dep group by nom_dep1 order by pourcentage1 desc";
    $rep1 = $bdd->query($query1);
    while( $ind = $rep1 ->fetch()){
    echo '<tr>';
    echo '<td>';
	echo $ind['nom_dep1'];
    echo '</td>';
    echo '<td>';
    echo $ind['pourcentage1'].'%';
    echo '</td>';    
    echo '</tr>'; 
   }
    }elseif ($selected_val=="construction"){
    $query2 = "SELECT departement.departement as nom_dep2, SUM(entreprise.construction) * 100 / (SELECT SUM(construction) FROM entreprise) as pourcentage2 from entreprise inner join departement on entreprise.Departement=departement.id_Dep group by nom_dep2 order by pourcentage2 desc";
    $rep2 = $bdd->query($query2);
    while( $cons = $rep2 ->fetch()){
    echo '<tr>';
    echo '<td>';
	echo $cons['nom_dep2'];
    echo '</td>';
    echo '<td>';
    echo $cons['pourcentage2'].'%';
    echo '</td>';    
    echo '</tr>'; 
   }
}    elseif ($selected_val=="transports restaurant hebergement"){
    $query3 = "SELECT departement.departement as nom_dep3, SUM(entreprise.TRH) * 100 / (SELECT SUM(TRH) FROM entreprise) as pourcentage3 from entreprise inner join departement on entreprise.Departement=departement.id_Dep group by nom_dep3 order by pourcentage3 desc";
    $rep3 = $bdd->query($query3);
    while($trh = $rep3 ->fetch()){
    echo '<tr>';
    echo '<td>';
	echo $trh['nom_dep3'];
    echo '</td>';
    echo '<td>';
    echo $trh['pourcentage3'].'%';
    echo '</td>';    
    echo '</tr>'; 
}
} elseif($selected_val=="Entreprises de services marchands aupres des menages"){
       $query4 = "SELECT departement.departement as nom_dep4, SUM(entreprise.ESMM) * 100 / (SELECT SUM(ESMM) FROM entreprise) as pourcentage4 from entreprise inner join departement on entreprise.Departement=departement.id_Dep group by nom_dep4 order by pourcentage4 desc";
    $rep4 = $bdd->query($query4);
    while($esmm = $rep4 ->fetch()){
    echo '<tr>';
    echo '<td>';
	echo $esmm['nom_dep4'];
    echo '</td>';
    echo '<td>';
    echo $esmm['pourcentage4'].'%';
    echo '</td>';    
    echo '</tr>'; 
} 
}
    elseif ($selected_val=="Entreprises de services marchands aupres des entreprises"){
   $query5 = "SELECT departement.departement as nom_dep5, SUM(entreprise.ESME) * 100 / (SELECT SUM(ESME) FROM entreprise) as pourcentage5 from entreprise inner join departement on entreprise.Departement=departement.id_Dep group by nom_dep5 order by pourcentage5 desc";
    $rep5 = $bdd->query($query5);
    while($esme = $rep5 ->fetch()){
    echo '<tr>';
    echo '<td>';
	echo $esme['nom_dep5'];
    echo '</td>';
    echo '<td>';
    echo $esme['pourcentage5'].'%';
    echo '</td>';    
    echo '</tr>'; 
} 
}
else {
   $query6 = "SELECT departement.departement as nom_dep6, SUM(entreprise.commerce) * 100 / (SELECT SUM(commerce) FROM entreprise) as pourcentage6 from entreprise inner join departement on entreprise.Departement=departement.id_Dep group by nom_dep6 order by pourcentage6 desc";
    $rep6 = $bdd->query($query6);
    while($com = $rep6 ->fetch()){
    echo '<tr>';
    echo '<td>';
	echo $com['nom_dep6'];
    echo '</td>';
    echo '<td>';
    echo $com['pourcentage6'].'%';
    echo '</td>';    
    echo '</tr>'; 
} 
}
}
   
?>
        
</table>
<br>
<br>
<?php 
include("pied_de_page.php");
?>  
</body>
</html>