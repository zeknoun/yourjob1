<!DOCTYPE html>
<html>
<head>

	<link rel="stylesheet"	href="yourjob.css"	type="text/css"	media="screen"	/>	
	<meta charset="utf-8"/>	
  <title> YourJob </title>
  
</head>


<body>

	
<?php 
include("menu.php");
?>	
<nav id="navi">
	<ul>
		<li id="act"><a href="page_accueil.html">CONSEILS CANDIDATURE</a>
		</li>
		</ul>
		</nav>



    <div id="conseil_p">
<p>Sur cette page, nous vous livrons quelques astuces et conseils avant de bien effectuer vos différentes candidatures de stages et/ou d'emplois. </p>
</div>

    
<?php 
include("pied_de_page.php");
?>  





</body>
</html> 