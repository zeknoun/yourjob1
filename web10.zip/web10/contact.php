<?php
 session_start();
 ?>
<?php
$civilite=$nom=$prenom=$email=$telephone=$autre=$sujet=$message="";
$nomErr=$prenomErr=$emailErr=$phoneErr=$autreErr=$messageErr="";

$aichaCool=false;
$emailTo="taichadiana.at@gmail.com";

if(!empty($_POST))
{
    $civilite=security($_POST['civilite']);
    $nom=security($_POST['nom']);
    $prenom=security($_POST['prenom']);
    $email=security($_POST['email']);
    $telephone=security($_POST['phone']);
    $autre=security($_POST['autre']);
    $sujet=security($_POST['sujet']);
    $message=security($_POST['message']);
    
    $aichaCool=true;
    
    if(empty($nom))
    {
        $nomErr="Veuillez renseigner votre nom svp!";
        $aichaCool=false;
    }    else
    {
        $textemail="Nom: $nom";
    }
    if(empty($prenom))
    {
        $prenomErr="Veuillez renseigner votre prenom svp!";
        $aichaCool=false;
    }    else
    {
        $textemail="Prenom: $prenom";
    }
     if(empty($email))
    {
        $emailErr="Veuillez renseigner votre adresse mail svp! ";
        $aichaCool=false;
    }    else
    {
        $textemail="Email: $email";
    }
    if(empty($telephone))
    {
        $phoneErr="Veuillez renseigner votre num&eacute;ro de telephone svp! ";
        $aichaCool=false;
    }      else
    {
        $textemail="Telephone: $telephone";
    }
      
    if(empty($autre))
    {
        $autreErr="Veuillez renseigner le sujet dans 'Autre' svp!";
        $aichaCool=false;
    }     else
    {
        $textemail="Autre sujet: $autre";
    }
    if(empty($message))
    {
        $messageErr="Veuillez renseigner votre message svp!";
        $aichaCool=false;
    }     else
    {
        $textemail="Message: $message";
    }
    
    if(!isMail($email))
    {
        $emailErr="Votre adresse mail n'est pas valide! ";
        $aichaCool=false;
    }   else
    {
        $textemail="Email: $email";
    }
    
    if(!isPhone($telephone))
    {
        $phoneErr="Entrez uniquement des chiffres! ";
        $aichaCool=false;
    }else
    {
        $textemail="Telephone: $telephone";
    }
    
    if($aichaCool)
    {
        $headers="From: $nom $prenom <email>\r\nReply-To:$email";
        mail($emailTo,"Messagerie",$textemail,$headers);
        $nom=$prenom=$telephone=$email=$message="";
        echo "Votre message a ete envoye avec succes!";
    }
}

function security($var)
{
    
    $var=stripslashes($var);
    $var=trim($var);
    $var=htmlspecialchars($var);
    return $var;
} 
function isMail($var)
{
    return filter_var($var,FILTER_VALIDATE_EMAIL);
}

function isPhone($var)
{
    
    return preg_match("/^[0-9 ]*$/",$var);
} 


    
?>
<!DOCTYPE html>
<html>
<head>

	<link rel="stylesheet"	href="yourjob.css"	type="text/css"	media="screen"	/>	
	<meta charset="utf-8"/>	
  <title> YourJob </title>
  <style>


html{
background-color: white;
}
#tableau1
{
	 border-collapse: separate;
        border-spacing: 30px 10px; 
background-color: #24786C;
color: white;
padding: 10px;
}
#bas
{
	 border-collapse: separate;
        border-spacing: 120px 20px; 
background-color: #24786C;
color: white;
}

#ac
{
	color: grey;
	background-color: #24786C;

}

#support{
    border-collapse: separate;
    border-spacing: 120px 20px; 
    background-color: #24786C;
    color: white;
    background-position: bottom;
    width :100%;
    bottom:0;
}

#contact{
font-size:23px;
padding-left: 400px;
background-color: #E6E6E6;
}

#champ{
font-style:italic;
color: grey;
text-align: center;
font-size: 15px;
}

a{
color: white;		
}

table{
	   border-collapse: separate;
    border-spacing: 30px 10px;
		font-size: 12px;
		
}

input{
width: 200px;
height: 20px;
}

textarea{
width: 300px;
}

#envoyer{
background-color: white;
}

select{
width: 300px;
}

.formulaire input{
width: 300px;
}

#ecrire{
font-size: 20px;
font-family: arial;
}

p{
text-align: center;
font-family: arial;
font-style: italic;
}

.texte{
font-size:15px;
font-family: arial;
}
      
    </style>
</head>


<body>


<?php 
include("menu.php");
?>	
<nav id="navi">
	<ul>
		<li id="act"><a href="page_accueil.html">support</a>
		</li>
		</ul>
		</nav>


    <p>Vous rencontrez des difficult&eacute;s sur notre site, n'h&eacute;sitez pas &agrave; nous contacter via le formulaire ci-dessous et nous vous r&eacute;pondrons d&egrave;s que possible.</p>
    
    
        <form action='' method="POST" >
<div id="contact">
<table>
    <tr>
        <td><img src="images/mail.png" height="40px" width="60px" alt="" /></td>
        <td> <div id="ecrire"> Nous &eacute;crire </div></td></tr>
    <tr>
        <td> <div class="texte"> <label for="civilite"> Civilit&eacute;: * </label></div> </td>
        <td><select name="civilite" id="civilite" name="civilite" placeholder="civilite" value=" <?php echo $civilite ?> ">
            <option> Mlle </option>
            <option>Mme</option>
            <option>M</option>
            </select>
        </td>
    </tr>
    <tr>
        <td><div class="texte"> <label for="nom"> Nom: * </label> </div></td>
        <td> <div class="formulaire"> <input type="text"  name="nom" placeholder="nom" value=" <?php echo $nom ?> "> </div> </td>
         <td><label style="color:red;"><?php echo $nomErr ?>
                      </label></td>
    </tr>
    <tr>
        <td><div class="texte"> <label for="prenom"> Pr&eacute;nom: * </label> </div></td>
        <td> <div class="formulaire"> <input type="text"  name="prenom" placeholder="prenom" value=" <?php echo $prenom ?> "> </div> </td>
         <td><label style="color:red;"><?php echo $prenomErr ?>
                      </label></td>
    </tr>    
    <tr>
        <td><div class="texte"> <label for="email"> Email: *  </label> </div></td>
        <td> <div class="formulaire"> <input type="text"  name="email" placeholder="email" value=" <?php echo $email ?> "> </div> </td>
         <td><label style="color:red;"><?php echo $emailErr ?> </label>
        </td>
    </tr> 
    <tr>
        <td><div class="texte"> <label for="phone"> Telephone: *  </label> </div></td>
        <td> <div class="formulaire"> <input type="text"  name="phone" placeholder="phone" value=" <?php echo $telephone ?> "> </div> </td>
        <td><label style="color:red;"><?php echo $phoneErr ?>
                      </label></td>
    </tr>
    <tr>
        <td> <div class="texte"><label for="sujet">Sujet: * </label> </div></td>
        <td><select name="sujet">
            <option> Probl&egrave;mes d'inscription </option>
            <option>Probl&egrave;mes donn&eacute;es</option>
            <option>Autre</option>
            </select>
        </td>
    </tr>
    <tr>
        <td><div class="texte"> <label for="autre"> Si autre, pr&eacute;cisez:  </label> </div></td>
        <td> <div class="formulaire"> <input type="text"  name="autre" placeholder="autre" value=" <?php echo $autre ?> "> </div> </td>
        <td><label style="color:red;"><?php echo $autreErr ?>
                      </label></td>
    </tr>   
    <tr>
      <td><div class="texte"><label for="message">message</label></div></td>
      <td> <div class="formulaire"> <textarea id="message" name="message"placeholder="message"><?php echo $message ?> </textarea></div></td>
      <td><label style="color:red;"><?php echo $messageErr ?></label></td>
    </tr> 
    <tr>
        <td><div id="boutton"><button>Envoyer</button></div> 
        </td>
    </tr>
</table>
</div>
</form>


<?php 
include("pied_de_page.php");
?>  



</body>
</html> 