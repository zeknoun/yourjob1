

<div id="support">
  <footer>
   <style>
      table{width: 100%;
      bottom: 0px;}
 
       .pied_page{
           color: white;
           size: 200px;
       } 
       .pied_page a{
           color: white;
           text-decoration: none;
           font-size: 15px;
       }
   
   </style>
   <table>
   <tr>
   <td><div class="pied_page"> <a href="resultat.php">Résultat d'enquête</a>   </div> </td>
   <td> <div class="pied_page"> <a href="liens.php">Liens utiles </a>  </div></td>
   <td> <div class="pied_page"> <a href="contact.php">Support</a>    </div>  </td>
   </tr>
   </table>
   </footer>
   </div>
