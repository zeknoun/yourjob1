Fichier t�l�charg� sur http://cmap.comersis.com

File downloaded at http://cmap.comersis.com

Fichier t�l�charg� sur www.comersis.com



L'acquisition des fichiers comersis.com inclut l'obtention d'une licence d'exploitation de ces fichiers,
en accord avec l'�diteur. 
Cette licence vous permettra d'utiliser imm�diatement les fichiers sur diff�rents supports,
en toute libert� et sans redevance suppl�mentaire.

COMERSIS.COM reste propri�taire des fichiers, en qualit� d'auteur.
Seul un droit non-exclusif d'utilisation d�fini comme suit est autoris�.



LICENCE D'UTILISATION DES FICHIERS TELECHARGES.

En prenant possession ou en ouvrant les fichiers, le client reconna�t �tre li� par les termes du pr�sent contrat de licence d'utilisation COMERSIS.
1/ Concession de licence - Par le pr�sent contrat, le client est autoris� � utiliser chaque exemplaire des fichiers t�l�charg�s 
sur un ordinateur unique ou dans une configuration monoposte. Si le client a acquis aupr�s de COMERSIS une licence r�seau, 
il peut installer les fichiers, sur un serveur et en permettre la consultation et l'utilisation par le nombre d'utilisateurs 
pr�vu par le contrat. Pour acqu�rir une licence d'utilisation r�seau ou multipostes, veuillez nous contacter.

2/ Restriction - Le client n'est pas autoris� � pr�ter ou donner en location les fichiers t�l�charg�s. Le client est cependant autoris�
 � les c�der d�finitivement, � la condition qu'il n'en conserve aucun exemplaire et que le cessionnaire accepte les termes du pr�sent contrat. 
Le client s'interdit de reconstituer la logique des informations, de d�compiler ou de d�sassembler les fichiers, s�par�ment ou dans leur ensemble.

3/ Droits d'auteur - Les fichiers sont la propri�t� exclusive de ses fournisseurs et sont prot�g�s par les dispositions du Code de la Propri�t� 
Intellectuelle et des trait�s internationaux en tant qu'oeuvre originale. Par cons�quent, le client doit traiter les fichiers comme toute oeuvre 
de l'esprit prot�g�e par le droit d'auteur. Seuls les documents sp�cifi�s comme tels sont libres d'utilisation.

4/ Responsabilit�s - COMERSIS ne saurait �tre responsable des dommages directs ou indirects ou fortuits � la suite de l'utilisation ou de 
l'incapacit� d'utiliser les fichiers. Le client est seul responsable de la bonne utilisation des fichiers et de l'utilisation qu'y en est faite, 
conform�ment aux termes de la pr�sente licence d'utilisation.

5/ Fonctionnement - COMERSIS estime que le client connait les formats et mode d'utilisation de ces fichiers.

6/ Garantie - COMERSIS, garantit dans le d�lai de 7 jours � compter de l'acquisition le remplacement de tout fichier d�fectueux. 
Tout fichier d�fectueux devra �tre retourn� au distributeur accompagn� d'une preuve d'achat.


7/ Avertissement - COMERSIS reste propri�taire des �l�ments inclus dans les fichiers, en qualit� d'auteur. Seul un droit non-exclusif d'utitlisation 
d�fini comme suit est autoris�. Les fichiers, en mode vectoriel sont propos�s pour des manipulations graphiques. Ils peuvent �tre int�gr�s dans tous 
travaux d'impression (livrets, plaquettes, affichettes...) et pr�sentations web. L'utilisation massive des fichiers comme pour l'�dition d'un atlas 
de g�ographie est soumise � autoristion pr�alable. La cession ou diffusion par tous moyens informatiques est interdite. Pour une int�gration 
multim�dia autre que internet, nous contacter. Tous droits r�serv�s.Toutes les op�rations autres que celles d�finies ci-dessus dans le contrat 
de licence d'utilisation sont interdites et susceptibles d'engager la responsabilit� de l'utilisateur









The acquisition of comersis.com files includes obtaining a license for these files, 
in agreement with the editor. 
This license allows you to immediately use the files on different media, 
freely and without additional charge. 

COMERSIS.COM retains ownership of files, as the author. 
Only a non-exclusive use is defined as authorized. 



LICENSE FOR DOWNLOADED FILES USE. 

By taking possession or opening files, the client agrees to be bound by the terms of this license agreement with COMERSIS. 
1 / Licensing - For this contract, the customer may use each downloaded files 
on a single computer or a stand-alone configuration. If the customer has purchased from COMERSIS a network license, 
it can install files on a server and allow access to and use by the users 
under the contract. To acquire a license or multi-network, please contact us. 

2 / Restriction - The customer is not allowed to lend or lease the downloaded files. The client is however allowed to assign definitively, provided it does retain no copies and the transferee accepts the terms of this contract. 
The customer agrees not to reconstruct the logic of information, decompile or disassemble the files separately or together. 

3 / Copyrights - The files are the exclusive property of its suppliers and are protected by the provisions of the Property Code 
Intellectual and international treaties as an original work. Therefore, the client should treat the files as any work 
of the mind protected by copyright. Only documents specified as such are free to use. 

4 / Disclaimer - COMERSIS not be liable for any direct or indirect or incidental damages as a result of the use or 
inability to use the files. The customer is solely responsible for the proper use of files and use what is made, 
accordance with the terms of this license. 

5 / Administration - COMERSIS believes that the client knows the formats and how to use these files. 

6 / Warranty - COMERSIS, guarantee within 7 days after the purchase replacement of any defective file. 
Any defective file will be returned to the dealer with proof of purchase. 


7 / Warning - COMERSIS retains ownership of the items included in the files, as the author. Only a non-exclusive utitlisation 
is defined as authorized. Files in vector mode are proposed for handling graphics. They can be integrated into all 
printing (booklets, leaflets, posters ...) and web presentations. Using massive files like editing an atlas 
Geography is subject to prior autoristion. The sale or distribution by any means is prohibited computer. For integration 
media other than the Internet, contact us. All rights reserved.All operations other than those described above in the contract 
Use License are prohibited and may engage the responsibility of the user.



http://map.comersis.com





Questions, made to measure maps : 

info@comersis.com

