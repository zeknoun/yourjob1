<?php
 session_start();
 ?>
<!DOCTYPE html> 
<html lang="fr">

<head> 
<style>
     
   
   </style>
<link	rel="stylesheet"	href="yourjob.css"	type="text/css"	media="screen"/>
<meta charset ="UTF-8">
<title>YourJob - R&eacute;gion</title>

</head>

<body>
<?php 
include("menu.php");
?>	
	
	

	
<nav id="navi">
	<ul>
		<li id="passif1"><a href="recherche_region.php">REGION</a>
		</li>
		<li id="passif2"><a href="departement.php">D&Eacute;PARTEMENT</a>
		</li>
		<li id="act1"><a href="commune.php">COMMUNE</a>
		</li>
	</ul>
</nav>


<div class="bord1" >	

	<?php	
	echo "<p>Vous avez choisi la commune : ".$_POST['comm']."</p>";
	?>

	<p>
		Les domaines d'activit&eacute;s majoritaires de la commune :
	</p>
	<ul>
		<li>Liste des domaines principaux
		</li>
	</ul>
	
	<?php
		$bdd = new PDO('mysql:host=localhost;dbname=yourjob1', 'root', '');
		$reponse = $bdd->query('SELECT sum(industrie)/(sum(totale)+sum(commerce))*100 as ind, sum(construction)/(sum(totale)+sum(commerce))*100 as cons, sum(TRH)/(sum(totale)+sum(commerce))*100 as trans, sum(ESME)/(sum(totale)+sum(commerce))*100 as ESM, sum(ESMM)/(sum(totale)+sum(commerce))*100 as ES, sum(commerce)/(sum(totale)+sum(commerce))*100 as com FROM entreprise where ARM="'.$_POST['comm'].'"');
			 
			while ($donnees = $reponse->fetch())
			{
			echo"<table>
			<tr>
				<th>Nom du secteur</th><th>Taux en %</th>
			</tr>
			<tr>
				<td>Industrie</td><td>".$donnees['ind']." % </td>
			</tr>
			<tr>
				<td>Construction</td><td>".$donnees['cons']." % </td>
			</tr>
			<tr>
				<td>Transport, Restauration et hotellerie</td><td>".$donnees['trans']." % </td>
			</tr>
			<tr>
				<td>ESME</td><td>".$donnees['ESM']." % </td>
			</tr>
			<tr>
				<td>ESMM</td><td>".$donnees['ES']." % </td>
			</tr>
			<tr>
				<td>Commerce</td><td>".$donnees['com']." % </td>
			</tr>
		</table>";
			}
		$reponse ->closeCursor(); 
	?>
</div>





<?php 
include("pied_de_page.php");
?>	



</body>
</html>