<!DOCTYPE html>
<html>
<head>

	<link rel="stylesheet"	href="yourjob.css"	type="text/css"	media="screen"	/>	
  <title> creation de compte</title>
 
 <?php 
 function Enregistrer($sexe,$nom,$prenom,$d_etude, $n_etude, $email, $mdp){
 try
 {
 $bdd = new PDO('mysql:host=localhost;dbname=yourjob;charset=utf8','root', '');
 $req="insert into utilisateur(civilite,nom, prenom, domaine_etude,niveau_etude, email, mdp) VALUES ('".$sexe."','".$nom."','".$prenom."','".$d_etude."','".$n_etude."','".$email."','".$mdp."')";
 $rep=$bdd->query($req);
 
  session_start();
 $_SESSION['utilisateur']=array($nom, $prenom);
 
 echo $req;
 }
catch (Exception $e)
{
	die ('Erreur:'.$e-> getMessage());
}
 }
	if($_GET['sexe']=="" || $_GET['nom']==""|| $_GET['prenom']==""|| $_GET['d_etude']==""||$_GET['n_etude']==""|| $_GET['email']==""||$_GET['boite']==""|| $_GET['mdp1']!=$_GET['mdp2'])
    {
		echo '<meta http-equiv="refresh" content="1; URL=utilisateur.php">';
	}
	else 
	{
		enregistrer($_GET['sexe'], $_GET['nom'], $_GET['prenom'], $_GET['d_etude'], $_GET['n_etude'], $_GET['email'], $_GET['mdp1']);
		echo '<meta http-equiv="refresh" content="1; URL=index.html">';
	}
 ?>
</head>



<body>
<h2> Cette page va &ecirc;tre r&eacute;dirig&eacute;e </h2> 

 
</body>
</html>