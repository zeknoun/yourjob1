<!DOCTYPE html>
<html>
<head>

	<link rel="stylesheet"	href="yourjob.css"	type="text/css"	media="screen"	/>	
	<meta charset="utf-8"/>	
  <title> YourJob </title>
  <style>
            
    </style>
</head>


<body>
<div id="tableau1">
<table>
<tr>
<td><a href="index.html"> ACCUEIL </a> </td>
<td> <a href="activite.html"> RECHERCHE PAR ACTIVITE </a></td>
<td> <a href="region.html"> RECHERCHE PAR REGIONS </a></td>
<td><a href="conseil.html"> CONSEILS CANDIDATURE </a></td>
<td>
<form>
  <div id="formulaire">
  <table>
    <tr>
	   <td><label for="uname">Identifiant</label></td>
	   <td> <input type="text" id="uname" name="name" placeholder="email"> </td>
    </tr>
    <tr>
	   <td> <label for="uname">Mot de passe</label> </td>
	   <td> <input type="password" id="uname" name="name" placeholder="********"> </td>
    </tr>	
    <tr>
	<td> <button> <a href="connexion.php">Se connecter </a></button> </td>   </tr>
	   <tr><td> <button> <a href="creation_compte.html"> Cr&eacute;er un compte </a></button> </td>
    </tr>
 </table>
  </div>
</form>
</td>
<td><DIV id="logo" align=right><img src="images/logo.png" height="100px" width="120px" alt="" /></DIV></td>
</tr>
</table>
</div>



<hr color=#24786C>

    
    <table>
<form method="get" action="enregistrement_e.php">
  <tr>
   <td> <input type="radio" name="sexe" value="M."> M. 
  <input type="radio" name="sexe" value="Mme" > Mme </td>
  </tr>
  
   <tr>
	      <td><label for="nom">Nom *</label></td> 
	     <td> 	 <label for="prenom">Prénom *</label> </td> 
   </tr>
   <tr>
	     <td><input type="text" id="nom" name="nom">
	     <td> <input type="text" id="prenom" name="prenom"> </td>
    </tr>	
     <tr>
        <td><label for="nom_ent">Nom de l'entreprise *</label></td>
    </tr>
    <tr>
     	 <td><input type="text" id="nom_ent" name="nom_ent" ></td>
    </tr>
     	
     	
    	<tr>
	    <td><label for="secteur_activite">Secteur d'activité *</label></td> 
	    <td>  <label for="annee_creation">Année de Création *</label> </td>
    </tr>
    <tr>
	    <td><select  name="secteur_activite"  id="secteur_activite">  
	    <option value="informatique" > Informatique</option>
	   <option value="statistique" > Statistique</option></select> </td>
	    <td> <input type="number" id="annee_creation" name="annee_creation" > </td>
    </tr>	
     <tr>
	   <td><label for="region">Région *</label></td>
	   <td> 	 <label for="departement">Département*</label> </td> 
    </tr>
    <tr>
	    <td><select name="region"  id="region" >
	    <option value="occitanie" > Occitanie</option>
	    <option value="ile de france " > Ile de france</option></select></td>
        
	    <td> <select id="departement" name="departement" > 
	    	    <option value="herault " > Herault</option>
	    	     <option value="paris " > Paris</option></select></td>
    </tr>	
   <tr>
       <td><label for="code_postal">code_postal *</label></td> 
	    <td> 	 <label for="ville">ville *</label> </td>
	 </tr>
    <tr>
       <td><input type="number" id="code_postal" name="code_postal"></td>
       <td> <input type="text" id="ville" name="ville" > </td>
    </tr>
    <tr>
       <td><label for="email">Email *</label></td>
    </tr>
    <tr>	
       <td><input type="email" id="email" name="email" ></td>
    </tr>
    <tr>
     	  <td><label for="mdp1">Mot de Passe *</label></td>
     	  <td> <label for="mdp2">Confirmer mot de passe  *</label></td>
    </tr>
    <tr>	
        <td><input type="password" id="mdp1" name="mdp1" placeholder="******"></td>	
         <td><input type="password" id="mdp2" name="mdp2" placeholder="******"></td>
    </tr>
    
  	
  	<tr>  
          <td> <p> <input type="checkbox" id="boite" name="boite" > J'accepte les conditions générales d'utilisation </p></td>
  	</tr>
  	<tr> <td><input type="submit" value="créer mon compte"> </td></tr>
     	</form>
     	</table>
     	
   
 

     
    
    

    
<br/>
<br/>


<div id="support">
   <table>
   <tr>
   <td>
   <u>  FAQ </u>  
   </td> 
      </tr>
   <tr>
   <td> <u><a href="contact.php"> Support </a>   </u>  </td>
   </tr>
   </table>
   </div>





</body>
</html> 