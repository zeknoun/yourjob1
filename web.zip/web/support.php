<!DOCTYPE html>
<html>
<head>
	
  <title> YourJob </title>
</head>
<style>

html{
background-color: white;
}
#tableau1
{
	 border-collapse: separate;
        border-spacing: 30px 10px; 
background-color: #24786C;
color: white;
padding: 10px;
}
#bas
{
	 border-collapse: separate;
        border-spacing: 120px 20px; 
background-color: #24786C;
color: white;
}

#ac
{
	color: grey;
	background-color: #24786C;

}

#support{
background-color: #04B4AE;
width: 100px;
height: 25px;
text-align: center;
color: black;
font-weight: bold;
text-decoration: underline;
}

#contact{
font-size:23px;
padding-left: 400px;
background-color: #E6E6E6;
}

#champ{
font-style:italic;
color: grey;
text-align: center;
font-size: 15px;
}

a{
color: white;		
}

table{
	   border-collapse: separate;
    border-spacing: 30px 10px;
		font-size: 12px;
		
}

input{
width: 200px;
height: 20px;
}

textarea{
width: 300px;
}

#envoyer{
background-color: white;
}

select{
width: 300px;
}

.formulaire input{
width: 300px;
}

#ecrire{
font-size: 20px;
font-family: arial;
}

p{
text-align: center;
font-family: arial;
font-style: italic;
}

.texte{
font-size:15px;
font-family: arial;
}

 


</style>


<body>
<div id="tableau1">
<table>
<tr>
<div id="ac">
<td><a href="index.html"> ACCUEIL </a>   </td>
</div>
<td> <a href="activite.html"> RECHERCHE PAR ACTIVITE </a></td>
<td> <a href="region.html"> RECHERCHE PAR REGIONS </a></td>
<td><a href="conseil.html"> CONSEILS CANDIDATURE </a></td>
<td>
<form>
  <div>
  <table>
    <tr>
	<td><label for="uname">Identifiant</label></td>
	<td> <input type="text" id="uname" name="name" placeholder="email"> </td>
    </tr>
    <tr>
	<td> <label for="uname">Mot de passe</label> </td>
	<td> <input type="password" id="uname" name="name" placeholder="********"> </td>
    </tr>	
    <tr>
	<td> <button> <a href="connexion.php">Se connecter </a></button> </td>   </tr>
	   <tr><td> <button> <a href="creation_compte.html"> Cr&eacute;er un compte </a></button> </td>
    </tr>
 </table>
  </div>
</form>
</td>
<td><DIV id="logo" align=right><img src="images/logo.png" height="100px" width="120px" alt="" /></DIV></td>
</tr>
</table>
</div>

<div id="support">
<p>SUPPORT</p>
</div>

<br/>

<br/>


<p>Vous rencontrez des difficult&eacute;s sur notre site, n'h&eacute;sitez pas &agrave; nous contacter via le formulaire ci-dessous et nous vous r&eacute;pondrons d&egrave;s que possible.</p>

<form action='' method="POST" >
<div id="contact">
<table>
<tr>
<td><img src="images/mail.png" height="40px" width="60px" alt="" /></td>
<td> <div id="ecrire"> Nous &eacute;crire </div></td></tr>
<tr>
<td> <div class="texte">Civilit&eacute;: * </div> </td>
<td><select name="civilite">
<option> Mlle </option>
<option>Mme</option>
<option>M</option>
</select></td>
</tr>
<tr>
<td><div class="texte">Nom: * </div></td>
<td> <div class="formulaire"> <input type="text"  name="nom"> </div> </td>
</tr>
<tr>
<td> <div class="texte">Pr&eacute;nom: *</div> </td>
<td> <div class="formulaire"><input type="text"  name="prenom"> </div> </td>
</tr>
<tr>
<td> <div class="texte">Email: * </div></td>
<td> <div class="formulaire"> <input type="email"  name="email">  </div></td>
</tr>
<tr>
<td> <div class="texte">T&eacute;l&eacute;phone: </div> </td>
<td> <div class="formulaire"> <input type="text"  name="phone">  </div></td>
</tr>
<tr>
<td> <div class="texte">Sujet: *  </div></td>
<td><select name="sujet">
<option> Probl&egrave;mes d'inscription </option>
<option>Probl&egrave;mes donn&eacute;es</option>
<option>Autre</option>
</select></td>
</tr>
<tr>
<td><div class="texte">Si autre, pr&eacute;cisez: </div> </td>
<td> <div class="formulaire"> <input type="text"  name="autre">  </div></td>
</tr>
<tr>
<td> <div class="texte">Message: *  </div></td>
<td> <textarea  name="message" rows=8 cols=50> </textarea> </td>
</tr>
<tr><td><div id="boutton"><button>Envoyer</button></div> </td></tr>
</table>
</div>
</form>


<div id="champ">
<p>Les champs marqu&eacute;s d'une * sont obligatoires</p>
 </div>
<br/>
<br/>

<?php
if(isset($_POST)&&!empty($_POST['civilite'])&&!empty($_POST['nom'])&&!empty($_POST['prenom'])&&!empty($_POST['email'])&&!empty($_POST['sujet'])&&!empty($_POST['message']))
{ 
extract($_POST);
$destinataire='taichadiana.at@gmail.com';
$expediteur=$nom.'<'.$email.'>';
$mail=mail($destinataire,$sujet,$message,$expediteur);
if($mail) echo 'Email envoye avec succes!';
else echo 'Echec envoi de mail';
}
else echo "Formulaire non soumis ou champ(s) vide(s)";

?>










<div id="bas">
   <table>
   <tr>
   <td>
   <u>  FAQ </u>  
   </td> 
      </tr>
   <tr>
   <td> <u><a href="support.html"> Support </a>   </u>  </td>
   </tr>
   </table>
   </div>





</body>
</html> 