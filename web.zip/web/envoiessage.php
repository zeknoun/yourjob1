<?php
$nom=$prenom=$telephone=$email=$message="";
$nomErr=$prenomErr=$phoneErr=$emailErr=$messageErr="";
$aichaCool=false;
if(!empty($_POST))
{
    $nom=security($_POST['nom']);
    $prenom=security($_POST['prenom']);
    $telephone=security($_POST['phone']);
    $email=security($_POST['email']);
    $message=security($_POST['message']);
    
    $aichaCool=true;
    if(empty($nom))
    {
        $nomErr="renseigne votre nom";
        $aichaCool=false;
    }    
    if(empty($prenom))
    {
        $prenomErr="renseigne votre prenom";
        $aichaCool=false;
    } 
    if(empty($telephone))
    {
        $phoneErr="renseigne votre phone ";
        $aichaCool=false;
    }   
    if(empty($email))
    {
        $emailErr="renseigne votre email ";
        $aichaCool=false;
    }    
    if(empty($message))
    {
        $messageErr="renseigne votre message ";
        $aichaCool=false;
    }  
    if(!isPhone($telephone))
    {
        $phoneErr="que des chiffre space ";
        $aichaCool=false;
    }
    if(!isMail($email))
    {
        $emailErr="ma aicha met un vrai mail stp ";
        $aichaCool=false;
    }
     if($aichaCool)  
     {
        echo "demain on va envoiyer le message merci bonne nuit mon coucou";
     }
         
        
    
}
function security($var)
{
    
    $var=stripslashes($var);
    $var=trim($var);
    $var=htmlspecialchars($var);
    return $var;
} 
function isPhone($var)
{
    
    return preg_match("/^[0-9 ]*$/",$var);
} 

function isMail($var)
{
    return filter_var($var,FILTER_VALIDATE_EMAIL);
}
    
?>


<!DOCTYPE html>
<html>
<head>

	<link rel="stylesheet"	href="yourjob.css"	type="text/css"	media="screen"	/>	
  <title> Cr&eacute;ation d'un compte </title>
</head>
<body>
    <form action="envoiessage.php" method="post">
          <div id="formulaire">
              <table>
                    <tr>
                      <td><label for="nom">nom</label></td>
                      <td> <input type="text" id="nom" name="nom" placeholder="nom" value=" <?php echo $nom ?> "></td>
                      <td><label style="color:red;"><?php echo $nomErr?>
                      </label></td>
                    </tr>
                    <tr>
                      <td><label for="prenom">prenom</label></td>
                      <td><input type="text"id="prenom" name="prenom" placeholder="prenom" value="<?php echo $prenom ?>"></td>
                      <td><label style="color:red;"><?php echo $prenomErr?></label></td>
                    </tr>
                    <tr>
                      <td><label for="phone">telephone</label></td>
                      <td><input type="text"id="phone"name="phone" placeholder="telephone" value="<?php echo $telephone ?>"></td>
                      <td><label style="color:red;"><?php echo $phoneErr?></label></td>
                    </tr>
                    <tr>
                      <td><label for="email">email</label></td>
                      <td> <input type="text" id="email" name="email" placeholder="email" value="<?php echo $email ?>"> </td>
                      <td><label style="color:red;"><?php echo $emailErr?></label></td>
                    </tr>
                    <tr>
                      <td><label for="message">message</label></td>
                      <td> <textarea id="message"name="message"placeholder="message"><?php echo $message ?></textarea></td>
                      <td><label style="color:red;"><?php echo $messageErr ?></label></td>
                    </tr>  
                    <tr>
                      
                      <td> <input type="submit" value="valide la star"> </td>
                      <td><label style="color:red;">envoi</label></td>
                    </tr>  
              </table>
         </div>
    </form>
</body>
</html> 