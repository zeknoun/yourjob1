<!DOCTYPE html>
<html>
<head>

	<link rel="stylesheet"	href="yourjob.css"	type="text/css"	media="screen"	/>	
  <title> Cr&eacute;ation d'un compte </title>
  <style>
  
#compte{
background-color: #04B4AE;
width: 220px;
height: 25px;
text-align: center;
color: black;
font-weight: bold;
text-decoration: underline;
}

#bas
{
	 border-collapse: separate;
        border-spacing: 120px 20px; 
background-color: #24786C;
color: white;
}
#creation
{
text-align:center;
color:#013ADF;
font-size: 40px;
font-family: arial;
margin: -20px;
}

hr
{
color:#08088A;
width: 70%;
line-height: 1;
}

#choix_compte
{
text-align:center;
font-family: arial;
font-size: 30px;
}

#test a
{
color: #013ADF;
font-size: 40px;
margin-left: 300px;
text-decoration: none;
}

#test :hover
{
    color : #58ACFA;
}

#test_tab table
{
	 border-collapse: separate;
        border-spacing: 320px 0px; 
}



  </style>
</head>


<body>
<div id="tableau1">
<table>
<tr>
<div id="ac">
<td><a href="index.html"> ACCUEIL </a>   </td>
</div>
<td> <a href="activite.html"> RECHERCHE PAR ACTIVITE </a></td>
<td> <a href="region.html"> RECHERCHE PAR REGIONS </a></td>
<td><a href="conseil.html"> CONSEILS CANDIDATURE </a></td>
<td>
<form>
  <div id="formulaire">
  <table>
    <tr>
	<td><label for="uname">Identifiant</label></td>
	<td> <input type="text" id="uname" name="name" placeholder="email"> </td>
    </tr>
    <tr>
	<td> <label for="uname">Mot de passe</label> </td>
	<td> <input type="password" id="uname" name="name" placeholder="********"> </td>
    </tr>	
    <tr>
	<td> <button> <a href="connexion.php">Se connecter </a></button> </td>   </tr>
	   <tr><td> <button> <a href="creation_compte.html"> Cr&eacute;er un compte </a></button> </td>
    </tr>
 </table>
  </div>
</form>
</td>
<td><DIV id="logo" align=right><img src="images/logo.png" height="100px" width="120px" alt="" /></DIV></td>
</tr>
</table>
</div>





<br/>



<div id="creation">
<p>CREATION D'UN COMPTE</p>
</div>

<hr>

<div id="choix_compte">
<p>Choisissez votre type de compte :</p>
</div>

<br/>





<div id="test">
<a href="utilisateur.php"> Utilisateur </a>
<a href="entrepreneur.php"> Entrepreneur </a>
</div>

<br/>


<div id="test_tab">
<table >
<tr><td><img src="images/utilisateur1.jpg" height="150px" width="160px" alt="" /></td>
<td><img src="images/entrepreneur.png" height="150px" width="160px" alt="" /></td></tr>
</table>
</div>




<br/>
<br/>



<div id="bas">
   <table>
   <tr>
   <td>
   <u>  FAQ </u>  
   </td> 
      </tr>
   <tr>
   <td> <u><a href="support.php"> Support </a>   </u>  </td>
   </tr>
   </table>
   </div>





</body>
</html> 