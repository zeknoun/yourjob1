<!DOCTYPE html>
<html>
<head>

	<link rel="stylesheet"	href="yourjob.css"	type="text/css"	media="screen"	/>	
	<meta charset="utf-8"/>	
  <title> YourJob </title>
  <style>
            
    </style>
</head>


<body>
<div id="tableau1">
<table>
<tr>
<td><a href="index.html"> ACCUEIL </a> </td>
<td> <a href="activite.html"> RECHERCHE PAR ACTIVITE </a></td>
<td> <a href="region.html"> RECHERCHE PAR REGIONS </a></td>
<td><a href="conseil.html"> CONSEILS CANDIDATURE </a></td>
<td>
<form>
  <div id="formulaire">
  <table>
    <tr>
	   <td><label for="uname">Identifiant</label></td>
	   <td> <input type="text" id="uname" name="name" placeholder="email"> </td>
    </tr>
    <tr>
	   <td> <label for="uname">Mot de passe</label> </td>
	   <td> <input type="password" id="uname" name="name" placeholder="********"> </td>
    </tr>	
    <tr>
	<td> <button> <a href="connexion.php">Se connecter </a></button> </td>   </tr>
	   <tr><td> <button> <a href="creation_compte.html"> Cr&eacute;er un compte </a></button> </td>
    </tr>
 </table>
  </div>
</form>
</td>
<td><DIV id="logo" align=right><img src="images/logo.png" height="100px" width="120px" alt="" /></DIV></td>
</tr>
</table>
</div>



<hr color=#24786C>


<table>
<tr>
<p> CONNEXION </p>
<p> COMPTE ENTREPRENEUR </p>
</tr>
<tr>
<td>
<form method="POST" action="connecter_e.php" >
  <div>
  <table>
	<tr>
	<td><p>Adresse email :  <input type="text" id="uname" name="email" placeholder="email"> </p></td>
    </tr>
    <tr>
	<td><p>Mot de passe :  <input type="password" id="uname" name="mdp" placeholder="********"> </p></td>
    </tr>	
    <tr>
	<td> <button>CONNEXION</button> </td>  
	</tr>
 </table>
  </div>
</form>
</td>
</tr>
</table>

<a href="creation_compte.php"> Pas inscrit? Cr&eacute;er un compte </a> 
   
 

     
    
    

    
<br/>
<br/>


<div id="support">
   <table>
   <tr>
   <td>
   <u>  FAQ </u>  
   </td> 
      </tr>
   <tr>
   <td> <u><a href="contact.php"> Support </a>   </u>  </td>
   </tr>
   </table>
   </div>





</body>
</html> 