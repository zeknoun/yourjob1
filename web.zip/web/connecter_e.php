<?php
 session_start();
 ?>
 <!DOCTYPE HTML>
<html>
<head>
<TITLE>connecter</TITLE>
<link rel="stylesheet" href="yourjob.css" type="text/css" media="screen"/>
    
<?php
if( $_POST['email']== "" || $_POST['mdp']== ""){	
	echo '<meta http-equiv="Refresh" content="1;url=connexion_e.php?">';
}
else{
	
	try{
		 $bdd = new PDO('mysql:host=localhost;dbname=yourjob;charset=utf8','root', '');
		$query = "select * from entrepreneur where email='".$_POST ['email']."' && mdp='".$_POST['mdp']."'";

		
		$rep = $bdd->query($query);		
		$ligne = $rep ->fetch();
		
		if ($ligne['nom'] != ""){
            $_SESSION['entrepreneur']=array($ligne['civilite'],$ligne['nom'],$ligne['prenom'],$ligne['nom_ent'],$ligne['secteur_activite'],$ligne['annee_creation'],$ligne['region'],$ligne['departement'],$ligne['code_postal'],$ligne['ville'],$ligne['email']);
            
			echo'<meta http-equiv="refresh" content="1; url=index.php">';
		}
		else{ 
			echo'<meta http-equiv="refresh" content="1; url=connexion_e.php">'; 
		}
	
	}
	catch(Exception $e){
		die ('Erreur :' .$e->getMessage());
	}
}
?>
</head>
<body>

</body>
</html>