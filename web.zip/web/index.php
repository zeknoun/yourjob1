<?php
 session_start();
 ?>
<!DOCTYPE html>
<html>
<head>

	<link rel="stylesheet"	href="yourjob.css"	type="text/css"	media="screen"	/>	
	<meta charset="utf-8"/>	
  <title> YourJob </title>
  <style>
            
    </style>
</head>


<body>
<div id="tableau1">
<table>
<tr>
<td><a href="index.php"> ACCUEIL </a> </td>
<td> <a href="activite.html"> RECHERCHE PAR ACTIVITE </a></td>
<td> <a href="region.html"> RECHERCHE PAR REGIONS </a></td>
<td><a href="conseil.html"> CONSEILS CANDIDATURE </a></td>
<td>
<form>
  <div id="formulaire">
  <table>	
    <tr>
      <?php      
        if (isset($_SESSION['entrepreneur'])){	
          echo"Bonjour";
		  echo " ";
		  echo $_SESSION['entrepreneur'][0];	
		  echo " ";
	      echo $_SESSION['entrepreneur'][1];
		  echo"<br>";
		  echo "<td>";
	      echo'<a href="deconnexion.php">Se d&eacute;connecter</a>';
          echo "</td>";
	   }elseif (isset($_SESSION['utilisateur'])){	
          echo"Bonjour";
		  echo " ";
		  echo $_SESSION['utilisateur'][0];	
		  echo " ";
	      echo $_SESSION['utilisateur'][1];
		  echo"<br>";
		  echo "<td>";
	      echo'<a href="deconnexion.php">Se d&eacute;connecter</a>';
          echo "</td>";
	   }
    else {
		echo "<tr>";
		echo "<td>";
        echo '<label for="uname">Identifiant</label>';
        echo "</td>";
        echo "<td>";
        echo '<input type="text" id="uname" name="name" placeholder="email">';
        echo "</td>";
        echo "</tr>";
        echo "<tr>";
        echo "<td>";
        echo '<label for="uname">Mot de passe</label>';
        echo "</td>"; 
        echo "<td>";
        echo '<input type="password" id="uname" name="name" placeholder="********"> ';
        echo "</td>";
        echo "</tr>";
        echo "<td>";    
        echo '<button ><a href="connexion.php" > Se connecter</a></button >';
		echo "</td>";
        echo "<tr><td>";
        echo '<button ><a href="creation_compte.php" > Creer un compte </a></button >';
		echo "</td></tr>";
                   }
                   
?>	
       </tr>
      
 </table>
  </div>
</form>
</td>
<td><DIV id="logo" align=right><img src="images/logo.png" height="100px" width="120px" alt="" /></DIV></td>
</tr>
</table>
</div>



<hr color=#24786C>
<div id="texte">
<p>YourJob, une nouvelle mani&egrave;re de rechercher un emploi!</p>
</div>

<hr color=#24786C>
<div id="image">
<marquee scrollamount="10">
<IMG src="images/emploi.png"/>
</marquee>
</div>
<hr color=#24786C>

<div id="site">
<h3>PRESENTATION DU SITE</h3>
</div>

<p>YourJob est un site de recherche d'emploi. Il pr&eacute;sente une nouvelle mani&egrave;re de rechercher un emploi. Sur ce site, la recherche peut s'effectuer de deux mani&egrave;res possibles: une recherche par r&eacute;gion/ d&eacute;partement et une recherche par domaine d'activit&eacute;. </p>
    
 

        <div id="menu_rech">
    <ul class="men">
        <li class="menu-act">Recherche par activit&eacute;</li>
        <p>La recherche par activité désigne tout simplement la recherche effectuée à partir d'un domaine d'activité donné. Cette recherche va permettre à l'utilisateur de trouver le(s) zone(s) gégraphique(s) françaises dans laquelle(lesquelles) le domaine d'activité choisi est le plus en hausse. 
            Pour cela, il devra, depuis la barre de menu, choisir <font color="blue">Recherche  par activité</font>, choisir le domaine d'activité dans lequel il souhaiterait exercer et renseigner également des informations sur la formation effectuée (type de diplôme, domaine de formation,...). Cette recherche présentera (par ordre décroissant) les régions, départements ou villes dans lesquels l'utilisateur a plus de chance d'obtenir un emploi en fonction du domaine d'activité sélectionné. </p>
        <li class="menu-reg">Recherche par r&eacute;gion </li>
        <p>La recherche par région, quant à elle, est une recherche effectuée à l'aide d'une zone géographique donnée (en France uniquement). Cette recherche permet de trouver les domaines d'activité les plus en hausse dans une zone géographique donnée. Pour effectuer cette recherche, choisissez, dans le menu de navigation, <font color="blue">Recherche par région</font>, sélectionnez la région souhaitée et suivez les différentes instructions pour passer les étapes. Vous obtiendrez ainsi les différents domaines d'activité dans lesquels vous avez le plus de chance d'exercer selon la zone géographique choisie.</p>
    </ul>

    
<br/>
<br/>


<div id="support">
   <table>
   <tr>
   <td>
   <u>  FAQ </u>  
   </td> 
      </tr>
   <tr>
   <td> <u><a href="contact.php"> Support </a>   </u>  </td>
   </tr>
   </table>
   </div>





</body>
</html> 