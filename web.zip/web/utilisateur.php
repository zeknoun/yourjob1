<!DOCTYPE html>
<html>
<head>

	<link rel="stylesheet"	href="yourjob.css"	type="text/css"	media="screen"	/>	
	<meta charset="utf-8"/>	
  <title> YourJob </title>
  <style>
            
    </style>
</head>


<body>
<div id="tableau1">
<table>
<tr>
<td><a href="index.html"> ACCUEIL </a> </td>
<td> <a href="activite.html"> RECHERCHE PAR ACTIVITE </a></td>
<td> <a href="region.html"> RECHERCHE PAR REGIONS </a></td>
<td><a href="conseil.html"> CONSEILS CANDIDATURE </a></td>
<td>
<form>
  <div id="formulaire">
  <table>
    <tr>
	   <td><label for="uname">Identifiant</label></td>
	   <td> <input type="text" id="uname" name="name" placeholder="email"> </td>
    </tr>
    <tr>
	   <td> <label for="uname">Mot de passe</label> </td>
	   <td> <input type="password" id="uname" name="name" placeholder="********"> </td>
    </tr>	
    <tr>
	<td> <button> <a href="connexion.php">Se connecter </a></button> </td>   </tr>
	   <tr><td> <button> <a href="creation_compte.html"> Cr&eacute;er un compte </a></button> </td>
    </tr>
 </table>
  </div>
</form>
</td>
<td><DIV id="logo" align=right><img src="images/logo.png" height="100px" width="120px" alt="" /></DIV></td>
</tr>
</table>
</div>



<hr color=#24786C>

 
    <table>
<form method=get action="enregistrement_u.php">
  <tr>
   <td> <input type="radio" name="sexe" value="M." > M. 
  <input type="radio" name="sexe" value="Mme" > Mme </td>
  </tr>
  <tr>
	      <td><label for="nom" >Nom *</label></td> 
	      <td><label for="prenom">Prénom *</label> </td> 
   </tr>
   <tr>
	     <td><input type="text" id="nom" name="nom" >
	     <td> <input type="text" id="prenom" name="prenom" > </td>
    </tr>	
    <tr>
	    <td><label for="d_etude">Domaine d'étude *</label></td> 
	    <td><label for="n_etude">Niveau d'étude *</label></td>    
    </tr>
    <tr>
     <td>
    <select  name="d_etude"  id="d_etude" >  
        <option value="informatique" > Informatique</option>
	    <option value="statistique" > Statistique</option>
    </select>
     </td>
     <td>
    <select  name="n_etude"  id="n_etude" > 
	   <option value="bac" > baccalauréat </option> 
	   <option value="bac+1" > bac +1</option>
	   <option value="bac+2" > bac +2</option> 
	   <option value="bac+3" > bac +3</option>
	   <option value="bac+4" > bac +4</option> 
	   <option value="bac+5" > bac +5</option>
    </select>
    </td>   
    </tr>	
    <tr>
       <td><label for="email">Email *</label></td>
    </tr>
    <tr>	
       <td><input type="email" id="email" name="email" ></td>
    </tr>
    <tr>
     	  <td><label for="mdp1">Mot de Passe *</label></td>
     	  <td> <label for="mdp2">Confirmer mot de passe  *</label></td>
    </tr>
    <tr>	
        <td><input type="password" id="mdp1" name="mdp1" placeholder="******"></td>	
         <td><input type="password" id="mdp2" name="mdp2" placeholder="******"></td>
    </tr>
  	<tr>  
          <td> <p> <input type="checkbox" id="boite" name="boite"> j'accepte les conditions générales d'utilisation </p></td>
  	</tr>
  	<tr> <td><input type="submit" value="Créer mon compte"> </td></tr>
     	</form>
     	</table>
     
    
    

    
<br/>
<br/>


<div id="support">
   <table>
   <tr>
   <td>
   <u>  FAQ </u>  
   </td> 
      </tr>
   <tr>
   <td> <u><a href="contact.php"> Support </a>   </u>  </td>
   </tr>
   </table>
   </div>





</body>
</html> 