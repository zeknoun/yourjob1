<html>
<head>

	<link rel="stylesheet"	href="yourjob.css"	type="text/css"	media="screen"	/>	
<title>Formulaire de contact</title>
</head>



<body>
<div id="tableau1">
<table>
<tr>
<td>ACCUEIL  </td>
<td> RECHERCHE PAR ACTIVITE </td>
<td> RECHERCHE PAR REGIONS </td>
<td> CONSEILS CANDIDATURE </td>
<td>
<form>
  <div>
  <table>
    <tr>
	<td><label for="uname">Identifiant</label></td>
	<td> <input type="text" id="uname" name="name" placeholder="email"> </td>
    </tr>
    <tr>
	<td> <label for="uname">Mot de passe</label> </td>
	<td> <input type="password" id="uname" name="name" placeholder="********"> </td>
    </tr>	
    <tr>
	<td> <button>Se connecter</button> </td>   </tr>
	   <tr><td> <button>Cr&eacute;er un compte</button> </td>
    </tr>
 </table>
  </div>
</form>
</td>
<td><DIV id="logo" align=right><img src="images/logo.png" height="100px" width="120px" alt="" /></DIV></td>
</tr>
</table>
</div>


<?php
if(isset($_POST['mailform']))
{
	if(!empty($_POST['nom']) AND !empty($_POST['mail']) AND !empty($_POST['message']))
	{
		$header="MIME-Version: 1.0\r\n";
		$header.='From:"PrimFX.com"<support@primfx.com>'."\n";
		$header.='Content-Type:text/html; charset="uft-8"'."\n";
		$header.='Content-Transfer-Encoding: 8bit';

		$message='
		<html>
			<body>
				<div align="center">
					<u>Nom de l\'expéditeur :</u>'.$_POST['nom'].'<br />
					<u>Mail de l\'expéditeur :</u>'.$_POST['mail'].'<br />
					<br />
					'.nl2br($_POST['message']).'
				</div>
			</body>
		</html>
		';

		mail("taichadiana.at@gmail.com", "CONTACT - Monsite.com", $message, $header);
		$msg="Votre message a bien été envoyé !";
	}
	else
	{
		$msg="Tous les champs doivent être complétés !";
	}
}
?>







<table width="370" height="245" border="1" align="center">
  <tr>
    <td align="center">Votre demande <br>
est bien prise en compte.<br>
<br>
Une r&eacute;ponse vous sera envoy&eacute;e prochainement.<br /> <strong>Merci, &agrave; bient&ocirc;t</strong><br /><br /><a href="http://adrien.naulet.free.fr">Retour vers le site</a></td>
  </tr>
  

<div id="support">
   <table>
   <tr>
   <td>
   <u>  FAQ </u>  
   </td> 
      </tr>
   <tr>
   <td> <u><a href="support.html"> Support </a>   </u>  </td>
   </tr>
   </table>
   </div>
  
</table>
</body>
</html>