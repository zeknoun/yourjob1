<!DOCTYPE html>
<html>
<head>

	<link rel="stylesheet"	href="yourjob.css"	type="text/css"	media="screen"	/>	
	<meta charset="utf-8"/>	
  <title> YourJob </title>
  <style>
            
    </style>
</head>


<body>
<?php 
include("menu.php");
?>	
<nav id="navi">
	<ul>
		<li id="passif1"><a href="connexion.php">CONNEXION</a>
		</li>
		<li id="act1"><a href="connexion_e.php">COMPTE ENTREPRENEUR</a>
		</li>
		</ul>
		</nav>
<table>
<tr>
<p>  </p>
<p>  </p>
</tr>
<tr>
<td>
<form method="POST" action="connecter_e.php" >
  <div>
  <table>
	<tr>
	<td><p>Adresse email :  <input type="text" id="uname" name="email" placeholder="email"> </p></td>
    </tr>
    <tr>
	<td><p>Mot de passe :  <input type="password" id="uname" name="mdp" placeholder="********"> </p></td>
    </tr>	
    <tr>
	<td> <button>CONNEXION</button> </td>  
	</tr>
 </table>
  </div>
</form>
</td>
</tr>
</table>

<a href="creation_compte.php"> Pas inscrit? Cr&eacute;er un compte </a> 
   
 

     
    
    

    
<br/>
<br/>


<?php
include("pied_de_page.php");
?>





</body>
</html> 