<!DOCTYPE html>
<html>
<head>

	<link rel="stylesheet"	href="yourjob.css"	type="text/css"	media="screen"	/>	
	<meta charset="utf-8"/>	
  <title> YourJob </title>
  <style>
            
    </style>
</head>


<body>
<?php 
include("menu.php");
?>	

<nav id="navi">
	<ul>
		<li id="act"><a href="utilisateur.php">compte utilisateur</a>
		</li>
		</ul>
</nav>

<div class="titre_création">
<p> Coordonées </p>
</div>
 
    <table>
<?php
try
{
    $bdd = new PDO('mysql:host=localhost;dbname=yourjob1', 'root', '');
}
catch(Exception $e)
{
    die('Erreur : '.$e->getMessage());
}
?>

<form method=get action="enregistrement_u.php">
  <tr>
   <td> <input type="radio" name="sexe" value="M." > M. 
  <input type="radio" name="sexe" value="Mme" > Mme </td>
  </tr>
  <tr>
	      <td><label for="nom" >Nom *</label></td> 
	      <td><label for="prenom">Prénom *</label> </td> 
   </tr>
   <tr>
	     <td><input type="text" id="nom" name="nom" >
	     <td> <input type="text" id="prenom" name="prenom" > </td>
    </tr>	
    <tr>
	    <td><label for="d_etude">Domaine d'étude *</label></td> 
	    <td><label for="n_etude">Niveau d'étude *</label></td>    
    </tr>
    <tr>
     <td>
    <select  name="d_etude"  id="d_etude" >  
	
	<?php
 
$reponse = $bdd->query('SELECT distinct lib_fil FROM formation');
 
while ($donnees = $reponse->fetch())
{
?>
<option value="<?php echo $donnees['lib_fil']; ?>"> <?php echo $donnees['lib_fil']; ?></option>
<?php
}
 
?>
</select>
     </td>
     <td>
    <select  name="n_etude"  id="n_etude" > 
	 <?php
 
$reponse = $bdd->query('SELECT distinct type_diplome FROM formation');
 
while ($donnees = $reponse->fetch())
{
?>
<option value="<?php echo $donnees['type_diplome']; ?>"> <?php echo $donnees['type_diplome']; ?></option>
<?php
}
 
?>
</select>
    </td>   
    </tr>	
    <tr>
       <td><label for="email">Email *</label></td>
    </tr>
    <tr>	
       <td><input type="email" id="email" name="email" ></td>
    </tr>
    <tr>
     	  <td><label for="mdp1">Mot de Passe *</label></td>
     	  <td> <label for="mdp2">Confirmer mot de passe  *</label></td>
    </tr>
    <tr>	
        <td><input type="password" id="mdp1" name="mdp1" placeholder="******"></td>	
         <td><input type="password" id="mdp2" name="mdp2" placeholder="******"></td>
    </tr>
  	<tr>  
          <td> <p> <input type="checkbox" id="boite" name="boite"> j'accepte les conditions générales d'utilisation </p></td>
  	</tr>
  	<tr> <td><input type="submit" value="Créer mon compte"> </td></tr>
     	</form>
     	</table>
     
    
    

    
<br/>
<br/>

<br>
<br>

<?php
include("pied_de_page.php");
?>






</body>
</html> 