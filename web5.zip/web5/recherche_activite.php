<html>
<head>
	<link rel="stylesheet"	href="yourjob.css"	type="text/css"	media="screen"	/>	
	<meta charset="utf-8"/>	
  
  <title> YourJob </title>

</head>

<body>

<?php 
//include("menu.php");
?>	
  

        <form method="post" action="resultat_activite.php">
    <select name="test">
        <option value="industrie" name="indiv">Industrie</option>
        <option value="construction" name="cons">construction</option>
        <option value="transports restaurant hebergement" name="trh">transports restaurant hébergement</option>
        <option value="Entreprises de services marchands aupres des menages" name="esmm">Entreprises de services marchands auprès des ménages</option>
        <option value="Entreprises de services marchands aupres des entreprises" name="esme">Entreprises de services marchands auprès des entreprises</option>
        <option value="commerce" name="com">commerce</option>
    </select>
    <input type="submit" name="submit" value="Rechercher" />
</form>
  
    
    

    
<?php 
//include("pied_de_page.php");
?>	


    
    

    
    
    
</body>
</html>