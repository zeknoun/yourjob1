
<div id="menu">
	<DIV><img id="logo"src="images/logo.jpg" alt="" />
	</DIV>

	<ul>
		<li id="pasm"><a href="page_accueil.php">ACCUEIL</a></li>
		<li id="pasm"><a href="page_accueil.php">RECHERCHE PAR ACTIVIT&Eacute;</a></li>
		<li id="pasm"><a href="recherche_region.php">RECHERCHE PAR R&Eacute;GION</a></li>
		<li id="pasm"><a href="conseils.php">CONSEILS CANDIDATURE</a></li>
	</ul>
</div>
<div id="menu2">
	<ul id="connex">
		<li id="Gc"><a href="creation_compte.php">Nouveau utilisateur</a></li>
		<li id="Dc"><a href="connexion.php">Connexion</a></li>
	</ul>
</div>	
