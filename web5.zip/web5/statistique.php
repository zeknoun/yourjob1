<!DOCTYPE html>
<html>
<head>

	<link rel="stylesheet"	href="yourjob.css"	type="text/css"	media="screen"	/>	
	<meta charset="utf-8"/>	
  <title> YourJob </title>
<script>
	function fct(choix){
		var pchoix = document.getElementById("a");
		if(choix == 1){
			pchoix.innerHTML = '<img src="images/capture1.png"/>';
		} else if(choix==2){
			pchoix.innerHTML = '<img src="images/capture2.png"/>'; 
		} else if(choix==3){
			pchoix.innerHTML = '<img src="images/capture3.png"/>';
		}
		else if(choix==4){
			pchoix.innerHTML = '<img src="images/capture4.png"/>';
		}
		else if(choix==5){
			pchoix.innerHTML = '<img src="images/capture5.png"/>';
		}
		else if(choix==6){
			pchoix.innerHTML = '<img src="images/capture11.png"/>';
		}
		else if(choix==7){
			pchoix.innerHTML = '<img src="images/capture12.png"/>';
		}
		else if(choix==8){
			pchoix.innerHTML = '<img src="images/capture13.png"/>';
		}
	}
</script>
</head>


<body>

<?php 
include("menu.php");
?>	
<br><br><br><br><br><br><br>
<div id="texte">
<p>YourJob, une nouvelle mani&egrave;re de rechercher un emploi!</p>
</div>
<h1>les résultats de l'enquête:</h1>
<input type="radio" name="photo" onclick="fct(1)"> Femmes et hommes ayant répondu au questionnaire: <br>
	<input type="radio" name="photo" onclick="fct(2)"> répartition selon l'âge:<br>
	<input type="radio" name="photo" onclick="fct(3)"> répartition selon la situation familial: <br>
	<input type="radio" name="photo" onclick="fct(4)"> répartition selon le domaine  d'études: <br>
	<input type="radio" name="photo" onclick="fct(5)"> répartition selon type de diplome:   <br>
	<input type="radio" name="photo" onclick="fct(6)">  préférence pour le mode de recherche   :   <br>
	<input type="radio" name="photo" onclick="fct(7)">  Difficultés rencontrées lors de votre recherche de stage/emploi:  <br>
	<input type="radio" name="photo" onclick="fct(8)">  Nombre de personnes intéresées par Yourjob:  <br>
	
	<div id="a"></div>

<?php 
include("pied_de_page.php");
?>	





</body>
</html> 