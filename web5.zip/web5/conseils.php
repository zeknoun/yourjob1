<!DOCTYPE html>
<html>
<head>

	<link rel="stylesheet"	href="yourjob.css"	type="text/css"	media="screen"	/>	
	<meta charset="utf-8"/>	
  <title> YourJob </title>
  <style>
            
    </style>
</head>


<body>

	
<?php 
include("menu.php");
?>	
<nav id="navi">
	<ul>
		<li id="act"><a href="page_accueil.html">CONSEILS CANDIDATURE</a>
		</li>
		</ul>
		</nav>



    <div id="conseil_p">
<p>Sur cette page, nous vous livrons quelques astuces et conseils avant de bien effectuer vos différentes candidatures de stages et/ou d'emplois. </p>
</div>

    
<br/>
<br/>


<div id="support">
   <table>
   <tr>
   <td>
   <u>  FAQ </u>  
   </td> 
      </tr>
   <tr>
   <td> <u><a href="contact.php"> Support </a>   </u>  </td>
   </tr>
   </table>
   </div>





</body>
</html> 