<!DOCTYPE html> 
<html lang="fr">

<head> 

<link	rel="stylesheet"	href="yourjob.css"	type="text/css"	media="screen"/>
<meta charset ="UTF-8">
<title>YourJob - R&eacute;gion</title>

</head>

<body>
<?php 
include("menu.php");
?>	
	
<nav id="navi">
	<ul>
		<li id="passif1"><a href="recherche_region.php">REGION</a>
		</li>
		<li id="act1"><a href="page_accueil.html">D&Eacute;PARTEMENT</a>
		</li>
	</ul>
</nav>


<div class="bord" id="gauche">
	<form method="post" action="commune.php" id="rech">
		<p>
			Choisissez votre commune de recherche :
		</p>
	
	   <p>
			<input type="text" name="comm" id="commune" placeholder="Saisir une commune">
	   </p>
	   <p>
			<INPUT TYPE="submit" NAME="envoie" VALUE="Rechercher">
	   </p>
	</form>
</div>



<div class="bord">
	<?php	
			$bdd = new PDO('mysql:host=localhost;dbname=yourjob1', 'root', '');
			$rep = $bdd->query('SELECT departement.departement FROM departement where id_Dep='.$_POST['dep']);

		
			echo "Vous avez choisi le département : ".$_POST['dep']." - ".$rep['departement'];
	
	?>

	<p>
		Les domaines d'activit&eacute;s majoritaires du pays :
	</p>
	<ul>
		<li>Liste des domaines principaux
		</li>
	</ul>
	
	<?php
			$reponse = $bdd->query('SELECT sum(industrie)/(sum(totale)+sum(commerce))*100 as ind, sum(construction)/(sum(totale)+sum(commerce))*100 as cons, sum(TRH)/(sum(totale)+sum(commerce))*100 as trans, sum(ESME)/(sum(totale)+sum(commerce))*100 as ESM, sum(ESMM)/(sum(totale)+sum(commerce))*100 as ES, sum(commerce)/(sum(totale)+sum(commerce))*100 as com FROM entreprise where Departement="'.$_POST['dep'].'"');

			while ($donnees = $reponse->fetch())
			{
			echo"<table>
			<tr>
				<th>Nom du secteur</th><th>Taux en %</th>
			</tr>
			<tr>
				<td>Industrie</td><td>".$donnees['ind']." % </td>
			</tr>
			<tr>
				<td>Construction</td><td>".$donnees['cons']." % </td>
			</tr>
			<tr>
				<td>Transport, Restauration et hotellerie</td><td>".$donnees['trans']." % </td>
			</tr>
			<tr>
				<td>ESME</td><td>".$donnees['ESM']." % </td>
			</tr>
			<tr>
				<td>ESMM</td><td>".$donnees['ES']." % </td>
			</tr>
			<tr>
				<td>Commerce</td><td>".$donnees['com']." % </td>
			</tr>
		</table>";
			}
		$reponse ->closeCursor(); 
	?>
</div>



<?php
include("pied_de_page.php");
?>


</body>
</html>