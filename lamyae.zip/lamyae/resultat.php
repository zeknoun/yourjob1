

<html>
<head>
  <meta http-equiv="Content-Type" content="text/html; charset=UTF-8"/>
  <link rel="stylesheet"
        type="text/css"
        href="./public/css/resultat.css"/>
  
  <title> YourJob </title>
</head>

<body>

<?php include './templates/header.php' ?>

<div>
  <h1>Resultant de recherché </h1>
</div>
<div>
  <INPUT type="submit" value="recharge">
</div>

<fieldset id=lamyae>
  <legend>DEPARTEMENT</legend>
  <table>
    <tr>
      <th>
        Nom de region
      </th>
      <th>
        Nombre des entreprise dans le secture choix
      </th>
	  <?php
	  $bdd = new PDO('mysql:host=localhost;dbname=yourjob;charset=utf8','root', '');	
							$sql = ("select ARM,Region from entreprise where industrie='".$industrie."' OR  ESME='".$ESME."'");	
							$rep = $bdd->query($sql);
							while ($line = $rep->fetch()){
							if(isset($line['industrie']==$industrie){
								echo"<tr><td>"
								.$line["ARM"].
								'</td><td>'
								.$line["Region"].
								"</td></tr>"
								}
							}
	$rep->closecursor();
?>
  </table>

</fieldset>

<fieldset id=lamyae2>
  <legend>QUELQUES ENTREPRISE</legend>
</fieldset>

<?php include './templates/footer.php' ?>

</body>
</html>