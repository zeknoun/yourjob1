<div id="tableau1">
  <table>
    <tr>
      <td>ACCUEIL</td>
      <td> RECHERCHE PAR ACTIVITE</td>
      <td> RECHERCHE PAR REGIONS</td>
      <td> CONSEILS CANDIDATURE</td>
      <td>
        <form>
          <div>
            <table>
              <tr>
                <td><label for="uname">Identifiant</label></td>
                <td><input type="text" id="uname" name="name" placeholder="email"></td>
              </tr>
              <tr>
                <td><label for="uname">Mot de passe</label></td>
                <td><input type="password" id="uname" name="name" placeholder="********"></td>
              </tr>
              </tr>
              <tr>
                <td>
                  <button>Se connecter</button>
                </td>
              </tr>
              <tr>
                <td>
                  <button>Cr&eacute;er un compte</button>
                </td>
              </tr>
            </table>
          </div>
        </form>
      </td>
      <td>
        <DIV id="logo" align=right><img src="./public/images/logo.png" height="100px" width="120px" alt=""/></DIV>
      </td>
    </tr>
  </table>
</div>