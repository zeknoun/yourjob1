<div id="pied_de_page">
  <footer>
    <p><a href="/faq.php"><h1>FAQ</h1></a></p>
    <p><a href="/contact.php"><h1>Support </h1></a></p>
  </footer>
  <div id="bas">
    <table>
      <tr>
        <td>
          <u>
            <a href="/faq.php">FAQ </a>
          </u>
        </td>
      </tr>
      <tr>
        <td><u><a href="/support.php"> Support </a> </u></td>
      </tr>
    </table>
  </div>
</div>