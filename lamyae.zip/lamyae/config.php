<?php

/**
 * Configuration for database connection
 * based on  :  https://www.taniarascia.com/create-a-simple-database-app-connecting-to-mysql-with-php/
 */

$host       = "localhost";
$username   = "root";
$password   = "root";
$dbname     = "yourjob";
$dsn        = "mysql:host=$host;dbname=$dbname";
$options    = array(
                PDO::ATTR_ERRMODE => PDO::ERRMODE_EXCEPTION
              );
?>