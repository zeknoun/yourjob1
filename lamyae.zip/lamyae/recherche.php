<html>
<head>
  <meta http-equiv="Content-Type" content="text/html; charset=UTF-8"/>
  <link rel="stylesheet"
        type="text/css"
        href="./public/css/recherche.css"/>
  
  <title> YourJob </title>

</head>

<body>
<?php include './templates/header.php' ?>
<center>
secteur d'activité:
<form method="post" action="resultat.php">
<SELECT name="secteur_activite">
<OPTION   name="construction"  VALUE="">construction</OPTION>
<OPTION   name="industrie"  VALUE="<?php if(isset($c['industrie']==$industrie) ?>">industrie</OPTION>
<OPTION    name="TRH"VALUE="">transports restaurant hébergement </OPTION>
<OPTION   name="ESME"VALUE="">Entreprises de services marchands auprès des ménages</OPTION>
<OPTION   name="ESMM"VALUE="">Entreprises de services marchands auprès des entreprises </OPTION>
<OPTION    name="commerce"VALUE="">commerce</OPTION>
<INPUT type="submit" value="recherche">
</form>
</center>
<?php include './templates/footer.php' ?>

</body>
</html>