<?php 
session_start();
?>
<!DOCTYPE html>
<html>
<head>

	<link rel="stylesheet"	href="yourjob.css"	type="text/css"	media="screen"	/>		
	<meta charset="utf-8"	/>		
  <title> Création de compte </title>
    
<?php
    
$sexe=$nom=$prenom=$nom_ent=$annee=$region=$departement=$cp=$ville=$email=$mdp1=$mdp2="";
$nomErr=$prenomErr=$entErr=$anneeErr=$cpErr=$villeErr=$emailErr=$mdp1Err=$mdp2Err="";

$ent=false;
    
    
function isMail($var)
{
    return filter_var($var,FILTER_VALIDATE_EMAIL);
}
   function isAnnee($var)
{
     return preg_match("/^[0-9 ]{4}$/",$var);
}
function isCp($var)
{
    return preg_match("/^[0-9 ]{5}$/",$var);
} 
    function security($var)
{
    
    $var=stripslashes($var);
    $var=trim($var);
    $var=htmlspecialchars($var);
    return $var;
}   

if(!empty($_GET))
{
    $nom=security($_GET['nom']);
    $prenom=security($_GET['prenom']);
    $nom_ent=security($_GET['nom_ent']);
    $annee=security($_GET['annee_creation']);
    $secteur_activite=security($_GET['secteur_activite']);
    $region=security($_GET['region']);
    $cp=security($_GET['code_postal']);
    $ville=security($_GET['ville']);
    $email=security($_GET['email']);
    $mdp1=security($_GET['mdp1']);
    $mdp2=security($_GET['mdp2']);
    
    $ent=true;
    
    if(empty($nom))
    {
        $nomErr="Veuillez renseigner votre nom svp!";
        $ent=false;
    } 
    if(empty($prenom))
    {
        $prenomErr="Veuillez renseigner votre prenom svp!";
        $ent=false;
    }     
    if(empty($nom_ent))
    {
        $entErr="Veuillez renseigner le nom de votre entreprise svp!";
        $ent=false;
    }   
     if(empty($annee))
    {
        $anneeErr="Veuillez saisir l'année de création de l'entreprise svp! ";
        $ent=false;
    }  
    if($annee <=2016 || $annee> date("Y"))
    {
        $anneeErr="L'année de création doit être supérieure à 2016 et inférieure à l'année actuelle";
        $ent=false;
    }      
     
     if(empty($ville))
    {
        $villeErr="Veuillez renseigner votre ville svp! ";
        $ent=false;
    } if(empty($cp))
    {
        $cpErr="Veuillez renseigner le code postal svp! ";
        $ent=false;
    }    
    if(empty($email))
    {
        $emailErr="Veuillez renseigner votre adresse mail svp!";
        $ent=false;
     

    $reqmail=$bdd->prepare("select * from entrepreneur where email=?");
    $reqmail=execute(array($email));
    $mailexiste=$reqmail->rowCount();
    if (mailexiste==0)
    {
  
        if(empty($mdp1))
    {
        $mdp1Err="Veuillez renseigner votre un mot de passe svp!";
        $ent=false;
    }   
        if(empty($mdp2))
    {
        $mdp2Err="Veuillez confirmer votre un mot de passe svp!";
        $ent=false;
    }  
          if($mdp1!=$mdp2)
    {
        $mdp1Err="Mots de passe différents";
        $ent=false;
    }  
    
      

      
    
    if(!isMail($email))
    {
        $emailErr="Votre adresse mail n'est pas valide! ";
        $ent=false;
    }  
    if(!isCp($cp))
    {
        $cpErr="Le code postal doit contenir 5 chiffres! ";
        $ent=false;
    }if(!isAnnee($annee))
    {
        $anneeErr="L'année doit contenir 4 chiffres! ";
        $ent=false;
    }
  }
    else{$emailErr="adresse mail deja utilisé";
    }
  
}
    if($ent)
    {
    function Enregistrer($sexe,$nom,$prenom,$nom_ent, $secteur_activite, $annee, $region, $departement, $code_postal, $ville, $email,      $mdp){
    try
    {
        $bdd = new PDO('mysql:host=localhost;dbname=yourjob1;charset=utf8','root', '');
        $req="insert into entrepreneur(civilite,nom, prenom,nom_ent, secteur_activite, annee_creation,region,departement,code_postal,ville, email, mdp) VALUES('".$sexe."','".$nom."','".$prenom."','".$nom_ent."','".$secteur_activite."','".$annee."','".$region."','".$departement."','".$code_postal."','".$ville."','".$email."','".$mdp."')";
        $rep=$bdd->query($req);
        
             if($secteur_activite=="industrie")
     {
        $entr=$bdd->query("select ARM, industrie from entreprise where ARM='".$ville."'");
        $li=$entr->fetch();
        $ind=$li['industrie'];
        $ind=$ind+1;
        $en=$bdd->query("update entreprise  set industrie='".$ind."' where ARM='".$ville."'");
     }
      elseif($secteur_activite=="construction")
     {
        $entr=$bdd->query("select ARM, construction from entreprise where ARM='".$ville."'");
        $li=$entr->fetch();
        $cons=$li['construction'];
        $cons=$cons+1;
        $en=$bdd->query("update entreprise  set construction='".$cons."' where ARM='".$ville."'");
     }      elseif($secteur_activite=="TRH")
     {
        $entr=$bdd->query("select ARM, TRH from entreprise where ARM='".$ville."'");
        $li=$entr->fetch();
        $trh=$li['TRH'];
        $trh=$trh+1;
        $en=$bdd->query("update entreprise  set TRH='".$trh."' where ARM='".$ville."'");
     }  elseif($secteur_activite=="ESME")
     {
        $entr=$bdd->query("select ARM, ESME from entreprise where ARM='".$ville."'");
        $li=$entr->fetch();
        $esme=$li['ESME'];
        $esme=$esme+1;
        $en=$bdd->query("update entreprise  set ESME='".$ESME."' where ARM='".$ville."'");
     } elseif($secteur_activite=="ESMM")
     {
        $entr=$bdd->query("select ARM, ESMM from entreprise where ARM='".$ville."'");
        $li=$entr->fetch();
        $esmm=$li['ESMM'];
        $esmm=$esmm+1;
        $en=$bdd->query("update entreprise  set ESMM='".$ESMM."' where ARM='".$ville."'");
     } 
        else 
     {
        $entr=$bdd->query("select ARM, commerce from entreprise where ARM='".$ville."'");
        $li=$entr->fetch();
        $com=$li['commerce'];
        $com=$com+1;
        $en=$bdd->query("update entreprise  set commerce='".$commerce."' where ARM='".$ville."'");
     }   
        
     $_SESSION['entrepreneur']=array($nom, $prenom);

     echo $req;
     }
    catch (Exception $e)
    {
        die ('Erreur:'.$e-> getMessage());
    }
     }
      
    if($_GET['sexe']=="")
    {
		echo '<meta http-equiv="refresh" content="1; URL=entrepreneur.php">';
	}
	else 
	{
		enregistrer($_GET['sexe'], $_GET['nom'], $_GET['prenom'], $_GET['nom_ent'], $_GET['secteur_activite'], $_GET['annee_creation'], $_GET['region'], $_GET['departement'], $_GET['code_postal'], $_GET['ville'], $_GET['email'], $_GET['mdp1']);
        echo '<meta http-equiv="refresh" content="1; URL=page_accueil.php">';
        echo "Votre compte a été créé avec succès! Vous allez être rédirigé vers la page d'accueil!";
	}
           
    }
}

?>
    
    
</head>
<body> 

<?php 
include("menu.php");
?>  
 <nav id="navi">
    <ul>
        <li id="passif1"><a href="creation_compte.php">Nouveau Utilisateur</a>
        </li>
        <li id="act1"><a href="entrepreneur.php">Compte Entrepreneur</a>
        </li>
        </ul>
        </nav>
    
    
<form action="" method="GET" >
<table>
    <tr>
   <td> <input type="radio" name="sexe" value="M."> M. 
       <input type="radio" name="sexe" value="Mme"> Mme </td> 
    </tr>
    <tr>
        <td><label for="nom"> Nom: * </label> </td>
        <td><input type="text"  name="nom" value=" <?php echo $nom ?> "></td>
         <td><label style="color:red;"><?php echo $nomErr ?></label></td>        
    </tr>
    <tr>
        <td><label for="prenom"> Prénom: * </label> </td>
        <td><input type="text"  name="prenom" value=" <?php echo $prenom ?> "></td>
         <td><label style="color:red;"><?php echo $prenomErr ?></label></td>
    </tr>     
    <tr>
        <td><label for="nom_ent"> Nom de l'entreprise: * </label> </td>
        <td><input type="text" name="nom_ent" value=" <?php echo $nom_ent ?> "></td>
         <td><label style="color:red;"><?php echo $entErr ?></label></td>
    </tr>      
    <tr>
        <td><label for="secteur_activite"> Secteur d'activité: * </label> </td>
        <td><select  name="secteur_activite"  id="secteur_activite" >  
	    <option value="industrie" > industrie</option>
	    <option value="construction" > construction</option>
	    <option value="trh" > TRH </option>
	    <option value="esme" > ESME </option>
	    <option value="esmm" > ESMM </option>
	    <option value="commerce" > commerce </option>
        </select> </td>
    </tr>   
    <tr>
        <td><label for="annee_creation"> Année de création: * </label> </td>
	    <td> <input type="text" id="annee_creation" name="annee_creation" value=" <?php echo $annee ?> "> </td>
        <td><label style="color:red;"><?php echo $anneeErr ?></label></td>
    </tr>   
    <tr>
        <td><label for="region">Région: *</label></td>
        <td>
        <select name="region"  id="region">
	    <?php
    
     $bdd = new PDO('mysql:host=localhost;dbname=yourjob1;charset=utf8','root', '');
    $reponse = $bdd -> query("select distinct departement.Region from departement inner join entreprise on departement.id_Dep=entreprise.Departement order by departement.Region asc");
  
                   while ($donnees = $reponse -> fetch())
   {
?>
    <option name="region" value="<?php echo $donnees['Region']; ?>" > <?php echo $donnees['Region']; ?></option>
            
    <?php

   }
    $region=$donnees['Region'];        
   ?>
       </select>
       </td>
    </tr>  
    
    <tr>
        <td><label for="departement">Département: *</label></td>
        <td>
        <select name="departement"  id="departement">
	    <?php
     $bdd = new PDO('mysql:host=localhost;dbname=yourjob1;charset=utf8','root', '');
    $reponse = $bdd -> query("select distinct Departement from departement order by Departement asc");

                   while ($donnees = $reponse -> fetch())
   {
?>
    <option value="<?php echo $donnees['Departement']; ?>" > <?php echo $donnees['Departement']; ?></option>
            
    <?php

   }
            
   ?>
       </select>
       </td>
    </tr>   
    
    <tr>
        
	    
            <td><label for="ville"> ville:* </label> </td>
        <td><input type="text"  name="ville" value=" <?php echo $ville ?> "> </td><td><h3><label style="color:grey;"> <p>1 ère lettre en majuscule et pas d'accent (ex: Orleans)</p></label></h3></td>

         <td><label style="color:red;"><?php echo $villeErr ?></label>   </td>   
   
       
       
             
    </tr> 
    <tr>
        <td><label for="code_postal">Code postal: *</label></td>
        <td><input type="text" id="code_postal" name="code_postal" value=" <?php echo $cp ?> "></td>
        <td><label style="color:red;"><?php echo $cpErr ?></label></td>
    </tr> 
    <tr>
        <td><label for="email">Email: *</label></td>
        <td><input type="text" id="email" name="email" value=" <?php echo $email ?> "></td>
        <td><label style="color:red;"><?php echo $emailErr ?></label></td>
    </tr>     
    <tr>
        <td><label for="mdp1">Mot de passe: *</label></td>
       <td><input type="password" id="mdp1" name="mdp1" placeholder="******"></td>	
        <td><label style="color:red;"><?php echo $mdp1Err ?></label></td>
    </tr>    
    <tr>
        <td><label for="mdp2">Confirmer mot de passe: *</label></td>
       <td><input type="password" id="mdp2" name="mdp2" placeholder="******"></td>	
        <td><label style="color:red;"><?php echo $mdp2Err ?></label></td>
    </tr>    
  	<tr> <td><input type="submit" value="créer mon compte"> </td></tr>
</table>
</form>
    

    
<br>
<br>
<br>


<?php 
include("pied_de_page.php");
?>  

</body>
</html> 