<?php
 session_start();
 ?>
<!DOCTYPE html>
<html>
<head>

	<link rel="stylesheet"	href="yourjob.css"	type="text/css"	media="screen"	/>	
	<meta charset="utf-8"/>	
  <title> YourJob </title>

 <?php
    
$nom=$prenom=$departement=$d_etude=$autre=$n_etude=$secteur_activite=$email=$mdp1=$mdp2="";
$nomErr=$prenomErr=$autreErr=$emailErr=$mdp1Err=$mdp2Err="";

$ent=false;
    
function isMail($var)
{
    return filter_var($var,FILTER_VALIDATE_EMAIL);
}
    function security($var)
{
    $var=stripslashes($var);
    $var=trim($var);
    $var=htmlspecialchars($var);
    return $var;
}   

    
if(!empty($_GET))
{

    $nom=security($_GET['nom']);
    $prenom=security($_GET['prenom']);
    $departement=security($_GET['departement']);
    $d_etude=security($_GET['d_etude']);
    $autre=security($_GET['autre']);
    $n_etude=security($_GET['n_etude']);
    $secteur_activite=security($_GET['secteur_activite']);
    $email=security($_GET['email']);
    $mdp1=security($_GET['mdp1']);
    $mdp2=security($_GET['mdp2']);
    
    $ent=true;  
    if(empty($nom))
    {
        $nomErr="Veuillez renseigner votre nom svp!";
        $ent=false;
    } 
    if(empty($prenom))
    {
        $prenomErr="Veuillez renseigner votre prenom svp!";
        $ent=false;
    }          
    if(empty($email))
    {
        $emailErr="Veuillez renseigner votre adresse mail svp!";
        $ent=false;
    }   
        if(empty($mdp1))
    {
        $mdp1Err="Veuillez renseigner votre un mot de passe svp!";
        $ent=false;
    }   
        if(empty($mdp2))
    {
        $mdp2Err="Veuillez confirmer votre un mot de passe svp!";
        $ent=false;
    }  
          if($mdp1!=$mdp2)
    {
        $mdp1Err="Mots de passe différents";
        $ent=false;
    }  
    if(!isMail($email))
    {
        $emailErr="Votre adresse mail n'est pas valide! ";
        $ent=false;
    }  
    if($ent)
    {
        
        function Enregistrer($sexe,$nom,$prenom,$departement,$d_etude,$autre, $n_etude,$secteur_activite, $email, $mdp){
        try
        {
        $bdd = new PDO('mysql:host=localhost;dbname=yourjob1;charset=utf8','root', '');
        $req="insert into utilisateur(civilite,nom, prenom, Departement, domaine_etude,autre_domaine,niveau_etude, secteur_activite, email, mdp) VALUES ('".$sexe."','".$nom."','".$prenom."','".$departement."','".$d_etude."','".$autre."','".$n_etude."','".$secteur_activite."','".$email."','".$mdp."')";
        $rep=$bdd->query($req);  
        
        if($d_etude="Autre" and !empty($autre))
     {
       $entr=$bdd->query("insert into formation (type_diplome, code_diplome, lib_fil, code_fil, secteur) values ('".$n_etude."', ' ', '".$autre."', ' ',' ')");
        $li=$entr->fetch();
     }
            
  session_start();
 $_SESSION['utilisateur']=array($nom, $prenom);
 
 echo $req;
 }
catch (Exception $e)
{
	die ('Erreur:'.$e-> getMessage());
}
 }
	if($_GET['sexe']=="")
    {
		echo '<meta http-equiv="refresh" content="1; URL=utilisateur.php">';
	}
	else 
	{
		enregistrer($_GET['sexe'], $_GET['nom'], $_GET['prenom'], $_GET['departement'], $_GET['d_etude'], $_GET['autre'], $_GET['n_etude'], $_GET['secteur_activite'], $_GET['email'], $_GET['mdp1']);
		echo '<meta http-equiv="refresh" content="1; URL=page_accueil.php">';
	} 
            
        }
}
    
?>
</head>
    

<body>

    
<?php 
include("menu.php");
?>
    
    
     <nav id="navi">
    <ul>
        <li id="passif1"><a href="creation_compte.php">Nouveau Compte </a>
        </li>
       <li id="act1"><a href="utilisateur.php">Compte Utilisateur</a>
        </li>
        </ul>
        </nav>

<form action="" method="GET" >
<table>
    <tr>
   <td> <input type="radio" name="sexe" value="M." > M. </td> 
        <td>  <input type="radio" name="sexe" value="Mme" > Mme </td> 
    </tr>
    <tr>
        <td><label for="nom"> Nom: * </label> </td>
        <td><input type="text"  name="nom" value=" <?php echo $nom ?> "></td>
         <td><label style="color:red;"><?php echo $nomErr ?></label></td>        
    </tr>
    <tr>
        <td><label for="prenom"> Prénom: * </label> </td>
        <td><input type="text"  name="prenom" value=" <?php echo $prenom ?> "></td>
         <td><label style="color:red;"><?php echo $prenomErr ?></label></td>
    </tr>    
        <tr>
        <td><label for="departement">Département: *</label></td>
        <td>
        <select name="departement"  id="departement">
     <?php
     $bdd = new PDO('mysql:host=localhost;dbname=yourjob1;charset=utf8','root', '');
    $reponse = $bdd -> query("select distinct Departement from departement order by Departement asc");

                   while ($donnees = $reponse -> fetch())
   {
     ?>
    <option value="<?php echo $donnees['Departement']; ?>" > <?php echo $donnees['Departement']; ?></option>        
    <?php
   }        
   ?>
       </select>
    </td>
    </tr> 
    <tr>
    <td><label for="d_etude">Domaine d'étude *</label></td> 
    <td><select  name="d_etude"  id="d_etude" value="<?php echo $d_etude ?>">  
    <option value="autre" > Autre </option>	
	<?php
 $bdd = new PDO('mysql:host=localhost;dbname=yourjob1;charset=utf8','root', '');
$reponse = $bdd->query('SELECT distinct lib_fil FROM formation order by lib_fil asc');
 
while ($donnees = $reponse->fetch())
{
?>
<option value="<?php echo $donnees['lib_fil']; ?>"> <?php echo $donnees['lib_fil']; ?></option>
        
<?php
}
 
?>
         
</select></td>
</tr> 
        <tr>
        <td><label for="autre"> Si autre:  </label> </td>
        <td><input type="text"  name="autre" value=" <?php echo $autre ?> "></td>
        <td><label style="color:red;"><?php echo $autreErr ?></label></td>        
        </tr>
<tr>
<td><label for="n_etude">Niveau d'étude *</label></td> 
<td><select  name="n_etude"  id="n_etude" >   
<?php
$bdd = new PDO('mysql:host=localhost;dbname=yourjob1;charset=utf8','root', '');
$reponse = $bdd->query('SELECT distinct type_diplome FROM formation');
while ($donnees = $reponse->fetch())
{
?>
<option value="<?php echo $donnees['type_diplome']; ?>"> <?php echo $donnees['type_diplome']; ?></option>
<?php
}
?>
</select></td>
  </tr> 
        <tr>
        <td><label for="secteur_activite"> Secteur d'activité recherché: * </label> </td>
        <td><select  name="secteur_activite"  id="secteur_activite" >  
	    <option value="industrie" > industrie</option>
	    <option value="construction" > construction</option>
	    <option value="trh" > TRH </option>
	    <option value="esme" > ESME </option>
	    <option value="esmm" > ESMM </option>
	    <option value="commerce" > commerce </option>
        </select> </td>
    </tr>  
    <tr>
        <td><label for="email">Email: *</label></td>
        <td><input type="text" id="email" name="email" value=" <?php echo $email ?> "></td>
        <td><label style="color:red;"><?php echo $emailErr ?></label></td>
    </tr>     
    <tr>
        <td><label for="mdp1">Mot de passe: *</label></td>
       <td><input type="password" id="mdp1" name="mdp1" placeholder="******"></td>	
        <td><label style="color:red;"><?php echo $mdp1Err ?></label></td>
    </tr>    
    <tr>
        <td><label for="mdp2">Confirmer mot de passe: *</label></td>
       <td><input type="password" id="mdp2" name="mdp2" placeholder="******"></td>	
        <td><label style="color:red;"><?php echo $mdp2Err ?></label></td>
    </tr>    
  	<tr> <td><input type="submit" value="créer mon compte"> </td></tr>
</table>
</form>
    

    
<br/>
<br/>

<br>
<br>

<?php
include("pied_de_page.php");
?>






</body>
</html> 