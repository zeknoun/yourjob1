<!DOCTYPE html>
<html>
<head>

	<link rel="stylesheet"	href="yourjob.css"	type="text/css"	media="screen"	/>	
    <meta charset="utf-8"/>	
  <title> Cr&eacute;ation d'un compte </title>
  <style>
  
#compte{
background-color: #04B4AE;
width: 220px;
height: 25px;
text-align: center;
color: black;
font-weight: bold;
text-decoration: underline;
}

#creation
{
text-align:center;
color:#013ADF;
font-size: 40px;
font-family: arial;
margin: -20px;
}

hr
{
color:#08088A;
width: 70%;
line-height: 1;
}

#choix_compte
{
text-align:center;
font-family: arial;
font-size: 30px;
}

#test a
{
color: #013ADF;
font-size: 40px;
margin-left: 300px;
text-decoration: none;
}

#test :hover
{
    color : #58ACFA;
}

#test_tab table
{
	 border-collapse: separate;
        border-spacing: 320px 0px; 
}



  </style>
</head>


<body>
<?php 
include("menu.php");
?>	


<nav id="navi">
	<ul>
		<li id="act"><a href="creation_compte.php">Nouveau Utilisateur</a>
		</li>
		</ul>
</nav>

<div id="creation">
<p>CREATION D'UN COMPTE</p>
</div>

<hr>

<div id="choix_compte">
<p>Choisissez votre type de compte :</p>
</div>

<br/>





<div id="test">
<a href="utilisateur.php"> Utilisateur </a>
<a href="entrepreneur.php"> Entrepreneur </a>
</div>

<br/>


<div id="test_tab">
<table >
<tr><td><img src="images/utilisateur1.jpg" height="150px" width="160px" alt="" /></td>
<td><img src="images/entrepreneur.png" height="150px" width="160px" alt="" /></td></tr>
</table>
</div>




<br/>
<br/>
<br>
<br>
<br>



<?php
include("pied_de_page.php");
?>





</body>
</html> 