

<div id="menu">
	<DIV><img id="logo"src="images/logo.jpg" alt="" />
	</DIV>

	<ul>
		<li id="pasm"><a href="page_accueil.php">ACCUEIL</a></li>
		<li id="pasm"><a href="recherche_activite.php">RECHERCHE PAR ACTIVIT&Eacute;</a></li>
		<li id="pasm"><a href="recherche_region.php">RECHERCHE PAR R&Eacute;GION</a></li>
		<li id="pasm"><a href="statistique.php">STATISTIQUES</a></li>
	</ul>
</div>
<div id="menu2">
	<ul id="connex">
      <?php  
        if (isset($_SESSION['entrepreneur'])){	
          echo '<li id="Gc">';
          echo"Bonjour";
		  echo " ";
		  echo $_SESSION['entrepreneur'][0];	
		  echo " ";
	      echo $_SESSION['entrepreneur'][1];
		  echo '</li>';
	      echo'<li id="Dc"><a href="deconnexion.php">Se d&eacute;connecter</a></li>';
	   } 
            elseif (isset($_SESSION['utilisateur'])){
          echo '<li id="Gc">';
          echo"Bonjour";
		  echo " ";
		  echo $_SESSION['utilisateur'][0];	
		  echo " ";
	      echo $_SESSION['utilisateur'][1];
		  echo '</li>';
	      echo'<li id="Dc"><a href="deconnexion.php">Se d&eacute;connecter</a></li>';
            }
         else { 
        echo '<li id="Gc"><a href="creation_compte.php"> Nouveau Compte </a></li>';
        echo '<li id="Dc"><a href="connexion.php">Connexion</a></li>';    
        }
        ?>

            </ul>
            </div>