<?php
 session_start();
 ?>
 <!DOCTYPE HTML>
<html>
<head>
<TITLE>connecter</TITLE>
<link rel="stylesheet" href="yourjob.css" type="text/css" media="screen"/>
    
<?php
if( $_POST['email']== "" || $_POST['mdp']== ""){	
	echo '<meta http-equiv="Refresh" content="1;url=connexion_u.php?">';
}
else{
	
	try{
		 $bdd = new PDO('mysql:host=localhost;dbname=yourjob;charset=utf8','root', '');
		$query = "select * from utilisateur where email='".$_POST ['email']."' && mdp='".$_POST['mdp']."'";

		
		$rep = $bdd->query($query);		
		$ligne = $rep ->fetch();
		
		if ($ligne['nom'] != ""){
            
			$_SESSION['utilisateur']=array($ligne['civilite'],$ligne['nom'],$ligne['prenom'],$ligne['domaine_etude'],$ligne['niveau_etude'],$ligne['email']);
			echo'<meta http-equiv="refresh" content="1; url=index.php">';
		}
		else{ 
			echo'<meta http-equiv="refresh" content="1; url=connexion_u.php">'; 
		}
	
	}
	catch(Exception $e){
		die ('Erreur :' .$e->getMessage());
	}
}
?>
</head>
<body>

</body>
</html>