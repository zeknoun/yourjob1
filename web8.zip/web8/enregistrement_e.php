<!DOCTYPE html>
<html>
<head>

	<link rel="stylesheet"	href="yourjob.css"	type="text/css"	media="screen"	/>	
  <title> creation de compte</title>
 
 <?php 
 function Enregistrer($sexe,$nom,$prenom,$nom_ent, $secteur_activite, $annee_creation, $region, $departement, $code_postal, $ville, $email, $mdp){
 try
 {
 $bdd = new PDO('mysql:host=localhost;dbname=yourjob;charset=utf8','root', '');
 $req="insert into entrepreneur(civilite,nom, prenom,nom_ent, secteur_activite, annee_creation,region,departement,code_postal,ville, email, mdp) VALUES ('".$sexe."','".$nom."','".$prenom."','".$nom_ent."','".$secteur_activite."','".$annee_creation."','".$region."','".$departement."','".$code_postal."','".$ville."','".$email."','".$mdp."')";
 $rep=$bdd->query($req);
 
  session_start();
 $_SESSION['entrepreneur']=array($nom, $prenom);
 
 echo $req;
 }
catch (Exception $e)
{
	die ('Erreur:'.$e-> getMessage());
}
 }
	if($_GET['sexe']=="" || $_GET['nom']==""|| $_GET['prenom']==""|| $_GET['nom_ent']==""||$_GET['secteur_activite']==""||$_GET['annee_creation']==""||$_GET['region']==""||$_GET['departement']==""||
    $_GET['code_postal']==""|| $_GET['ville']==""|| $_GET['email']==""||$_GET['boite']==""|| $_GET['mdp1']!=$_GET['mdp2'])
    {
		echo '<meta http-equiv="refresh" content="1; URL=entrepreneur.php">';
	}
	else 
	{
		enregistrer($_GET['sexe'], $_GET['nom'], $_GET['prenom'], $_GET['nom_ent'], $_GET['secteur_activite'], $_GET['annee_creation'], $_GET['region'], $_GET['departement'], $_GET['code_postal'], $_GET['ville'], $_GET['email'], $_GET['mdp1']);
        echo '<meta http-equiv="refresh" content="30; URL=index.html">';
        echo "Bienvenu(e) sur YourJob!!!";
	}
 ?>
</head>



<body>
<h2> Votre compte a été créé avec succès!</h2> 

 
</body>
</html>