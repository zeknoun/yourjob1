<!DOCTYPE html>
<html>
<head>

	<link rel="stylesheet"	href="yourjob.css"	type="text/css"	media="screen"	/>	
	<meta charset="utf-8"/>	
  <title> YourJob </title>
  <style>
        #support{position: fixed;}  
      h3{margin-left: 30px;
        margin-top: -50px;
        margin-right: 75%;
        float: right;
        color: grey;}
   
    </style>
</head>


<body>
<?php 
include("menu.php");
?>	
<nav id="navi">
	<ul>
		<li id="passif1"><a href="connexion.php">CONNEXION</a>
		</li>
		<li id="act1"><a href="connexion_e.php">COMPTE ENTREPRENEUR</a>
		</li>
		</ul>
		</nav>
<table>
<tr>
<p>  </p>
<p>  </p>
</tr>
<tr>
<td>
<form method="POST" action="connecter_e.php" >
  <div>
  <table>
	<tr>
	<td><p>Adresse email :  <input type="text" id="uname" name="email" placeholder="email"> </p></td>
    </tr>
    <tr>
	<td><p>Mot de passe :  <input type="password" id="uname" name="mdp" placeholder="********"> </p></td>
    </tr>	
    <tr>
	<td> <button>CONNEXION</button> </td>  
	</tr>
 </table>
  </div>
</form>
</td>
</tr>
</table>

<h3><a href="creation_compte.php">Cr&eacute;er un compte </a> </h3>
   
 

     
    
    

    
<br/>
<br/>



<div id="support">
   <style>
      table{width: 100%;}

   
   </style>
   <table>
   <tr>
   <td>
   <u>  <a href="resultat.php">résultat d'enquête</a>  </u>   </td>
   <td> <a href="liens.php">Liens utiles </td>
   <td> <u> <a href="contact.php">Support</a>   </u>  </td>
   </tr>
   </table>
   </div>





</body>
</html> 