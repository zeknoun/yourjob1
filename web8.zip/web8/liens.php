<!DOCTYPE html>
<html>
<head>
<style>
     
#support{position: fixed;}
   
   </style>
	<link rel="stylesheet"	href="yourjob.css"	type="text/css"	media="screen"	/>	
	<meta charset="utf-8"/>	
  <title> YourJob </title>
</script>
</head>


<body>

<?php 
include("menu.php");
?>	
<nav id="navi">
	<ul>
		<li id="act"><a href="lien.php">Liens Utiles</a>
		</li>
	</ul>
</nav>

<h1>Pour rédiger votre curriculum vitae:</h1>
<br/>
<ul>
<li>
<a href="https://www.keljob.com/articles/faire-rediger-son-cv-par-un-pro-a-qui-s-adresser">KEljob</a>
</li>
<li>
<a href="http://www.creeruncv.com/">creeruncv</a>
</li>
<li>
<a href="https://www.studentjob.fr/blog/937-5-outils-indispensables-pour-faire-son-cv">studentjob</a>
</li>
</ul>
<h1>Pour rédiger votre letter de motivation :</h1>

<ul>
<li>
<a href="http://etudiant.aujourdhui.fr/etudiant/info/exemple-de-lettre-de-motivation.html">leparisien</a>
</li>
<li>
<a href="https://www.doc-etudiant.fr/Methodologie/Lettre-de-motivation/">digiscool</a>
</li>
<li>
<a href="https://www.journaldunet.fr/management/guide-du-management/1200753-lettre-de-motivation-conseils-exemple-type/">journaldunet</a>
</li>
</ul>



<div id="support">
   <style>
      table{width: 100%;}

   
   </style>
   <table>
   <tr>
   <td>
   <u>  <a href="resultat.php">résultat d'enquête</a>  </u>   </td>
   <td> <a href="liens.php">Liens utiles </td>
   <td> <u> <a href="contact.php">Support</a>   </u>  </td>
   </tr>
   </table>
   </div>




</body>
</html> 