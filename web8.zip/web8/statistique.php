<!DOCTYPE html>
<html>
<head>
<style> #support{position: fixed;}</style>
	<link rel="stylesheet"	href="yourjob.css"	type="text/css"	media="screen"	/>	
	<meta charset="utf-8"/>	
  <title> YourJob </title>
<script>
	function fct(choix){
		var pchoix = document.getElementById("a");
		if(choix == 1){
			pchoix.innerHTML = '<img src="images/graph1.png"/>';
		} else if(choix==2){
			pchoix.innerHTML = '<img src="images/graph2.png"/>'; 
		} else if(choix==3){
			pchoix.innerHTML = '<img src="images/graph3.png"/>';
		}
		else if(choix==4){
			pchoix.innerHTML = '<img src="images/graph4.png"/>';
		}
		else if(choix==5){
			pchoix.innerHTML = '<img src="images/graph5.png"/>';
		}
		else if(choix==6){
			pchoix.innerHTML = '<img src="images/graph6.png"/>';
		}
		else if(choix==7){
			pchoix.innerHTML = '<img src="images/graph7.png"/>';
		}
		else if(choix==8){
			pchoix.innerHTML = '<img src="images/graph8.png"/>';
		}
		else if(choix==9){
			pchoix.innerHTML = '<img src="images/graph9.png"/>';
		}
		
	}
</script>
</head>


<body>

<?php 
include("menu.php");
?>	

<nav id="navi">
	<ul>
		<li id="act"><a href="statistique.php">Statistique du nombre d'entreprise par region :</a>
		</li>
	</ul>
</nav>


<input type="radio" name="photo" onclick="fct(1)"> Auvergne-Rhone-Alpes: <br>
	<input type="radio" name="photo" onclick="fct(2)"> Centre-Val de Loire:<br>
	<input type="radio" name="photo" onclick="fct(3)"> Grand-Est: <br>
	<input type="radio" name="photo" onclick="fct(4)"> Ile-de-France: <br>
	<input type="radio" name="photo" onclick="fct(5)"> Normandie:   <br>
	<input type="radio" name="photo" onclick="fct(6)">  Nouvelle-Aquitaine:   <br>
	<input type="radio" name="photo" onclick="fct(7)">  Occitanie:  <br>
	<input type="radio" name="photo" onclick="fct(8)">  Pays-de-la-Loire:  <br>
	<input type="radio" name="photo" onclick="fct(9)">  Provence-Alpes-Cote d'Azur:  <br>
	
	<div id="a"></div>

	<br>
	<br>
	<br>

<div id="support">
   <style>
      table{width: 100%;}

   
   </style>
   <table>
   <tr>
   <td>
   <u>  <a href="resultat.php">résultat d'enquête</a>  </u>   </td>
   <td> <a href="liens.php">Liens utiles </td>
   <td> <u> <a href="contact.php">Support</a>   </u>  </td>
   </tr>
   </table>
   </div>






</body>
</html> 