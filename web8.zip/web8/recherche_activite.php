<html>
<head>
	<link rel="stylesheet"	href="yourjob.css"	type="text/css"	media="screen"	/>	
	<meta charset="utf-8"/>	
  
  <title> YourJob </title>
</head>

<body>

<?php 
include("menu.php");
?>	

<nav id="navi">
    <ul>
        <li id="act"><a href="recherche_activite.php">Activité</a>
        </li>
    </ul>
</nav>
<div class="bord" id="gauche">
    <h3>S&eacute;lectionnez votre Activité recherché :</h3>
    </br>
  

        <form method="post" action="resultat_activite.php">
    <select name="test">
        <option value="industrie" name="indiv">Industrie</option>
        <option value="construction" name="cons">construction</option>
        <option value="transports restaurant hebergement" name="trh">transports restaurant hébergement</option>
        <option value="Entreprises de services marchands aupres des menages" name="esmm">Entreprises de services marchands auprès des ménages</option>
        <option value="Entreprises de services marchands aupres des entreprises" name="esme">Entreprises de services marchands auprès des entreprises</option>
        <option value="commerce" name="com">commerce</option>
    </select>
    <input type="submit" name="submit" value="Rechercher" />
</form>
  <p> votre selection sera effectuée sur l'un des six plus grand domaines d'activité relaté sur le territoire français </p> 
 </div>


    <div class="bord">
    <p>
        Les domaines d'activit&eacute;s majoritaires du pays :
    </p>
    <ul>
        <li>Liste des domaines principaux
        </li>
    </ul>
    <table>
        <tr>
            <th>Nom de la r&eacute;gion</th><th>Industrie</th><th>Construction</th><th>Transport, Restauration et hotellerie</th><th>ESME</th><th>ESMM</th><th>Commerce</th>
        </tr>
        <?php
        $bdd = new PDO('mysql:host=localhost;dbname=yourjob1', 'root', '');
        $requete = $bdd->query('SELECT distinct departement.Region, sum(industrie)/(sum(totale)+sum(commerce))*100 as ind, sum(construction)/(sum(totale)+sum(commerce))*100 as cons, sum(TRH)/(sum(totale)+sum(commerce))*100 as trans, sum(ESME)/(sum(totale)+sum(commerce))*100 as ESM, sum(ESMM)/(sum(totale)+sum(commerce))*100 as ES, sum(commerce)/(sum(totale)+sum(commerce))*100 as com FROM departement, entreprise where entreprise.Departement = departement.id_Dep group by departement.Region');
             
            while ($data = $requete->fetch())
            {
            echo"
            <tr>
                <td>".$data['Region']."</td><td>".$data['ind']." % </td><td>".$data['cons']." % </td><td>".$data['trans']." % </td><td>".$data['ESM']." % </td><td>".$data['ES']." % </td><td>".$data['com']." % </td>
            </tr>";
            }
        $requete ->closeCursor(); 
    ?>
    </table>
</div>
<br>
<br>

    
<?php 
include("pied_de_page.php");
?>	


    
    

    
    
    
</body>
</html>