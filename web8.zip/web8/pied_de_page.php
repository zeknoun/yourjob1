

<div id="support">
   <style>
      table{width: 100%;
      position:static;}

   
   </style>
   <table>
   <tr>
   <td>
   <u>  <a href="resultat.php">résultat d'enquête</a>  </u>   </td>
   <td> <a href="liens.php">Liens utiles </td>
   <td> <u> <a href="contact.php">Support</a>   </u>  </td>
   </tr>
   </table>
   </div>
