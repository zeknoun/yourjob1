<!DOCTYPE html> 
<html lang="fr">

<head> 

<link	rel="stylesheet"	href="yourjob.css"	type="text/css"	media="screen"/>
<meta charset ="UTF-8">
<title>YourJob - R&eacute;gion</title>

</head>

<body>
/*Barre menu*/
<?php 
include("menu.php");
?>	
	
<nav id="navi">
	<ul>
		<li id="act"><a href="recherche_region.php">REGION</a>
		</li>
	</ul>
</nav>

<div class="bord" id="gauche">
	<p>S&eacute;lectionnez votre zone de recherche :</p>
	</br>
	<script src="cmap/france-map.js"></script>
	<script>francefree();</script>
</div>

<p id="ou">
	<strong>OU</strong>
</p>

<div class="bord">
	<p>
		Choisissez votre d&eacute;partement ou votre commune de recherche :
	</p>
	
	<form method="post" action="departement_seul.php" id="rech">
		<p>
		   <label for="dep">Choix d'un d&eacute;partement</label><br />
		   <select name="dep" id="dep">
		   <?php
				$bdd = new PDO('mysql:host=localhost;dbname=yourjob1', 'root', '');
				$reponse = $bdd->query('SELECT id_Dep, departement FROM departement');
				 
				while ($donnees = $reponse->fetch())
				{
			?>
				<option name="dep"> <?php echo $donnees['id_Dep']." - ".$donnees['departement']; ?></option>
			<?php
				}
			?>
		   </select>
	   </p>
	   <p>
			<INPUT TYPE="submit" NAME="envoie" VALUE="Rechercher">
	   </p>
	</form>
	<form method="post" action="commune.php" id="rech">
		<p>
			Choisissez votre commune de recherche :
		</p>
	   <p>
			<input type="text" name="comm" id="commune" placeholder="Saisir une commune">
	   </p>
	   <p>
			<INPUT TYPE="submit" NAME="envoie" VALUE="Rechercher">
	   </p>
	</form>
	
</div>



<p id="graph">
	
</p>





<?php 
include("pied_de_page.php");
?>	

</body>
</html>